FIREPLACE Kodi Add-on v1.0.0

A tiny fireplace ambience launcher designed with Raspberry Pi / low-storage
Kodi setups in mind.

The addon does not bundle large video files. Instead, each preset opens a
web search for that atmosphere in the device's browser.

Presets:
- Crackling Fire
- Roaring Fire
- Midnight Fire
- Fire + Rain
- Winter Fire
- Campfire
- Random Fire

Built for Kodi Python 3.
