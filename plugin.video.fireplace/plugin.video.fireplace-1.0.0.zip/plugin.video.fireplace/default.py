# -*- coding: utf-8 -*-
import sys
import urllib.parse
import subprocess
import shutil
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])

# Public YouTube search handoffs keep the addon tiny: no giant video files
# are bundled with the ZIP, which is friendlier to Raspberry Pi storage.
PRESETS = {
    "crackling": "cozy crackling fireplace 4K",
    "roaring": "roaring fireplace ambience 4K",
    "midnight": "midnight fireplace ambience dark",
    "rain": "fireplace rain ambience",
    "winter": "winter fireplace ambience snow",
    "campfire": "campfire ambience night",
}

def open_browser(url):
    for cmd in ("xdg-open", "gio", "sensible-browser"):
        if shutil.which(cmd):
            try:
                subprocess.Popen([cmd, url],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
                return True
            except Exception:
                pass
    return False

def launch(label, query):
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote(query)
    if open_browser(url):
        xbmcgui.Dialog().notification(
            "FIREPLACE",
            label + " search opened in your browser.",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
    else:
        xbmcgui.Dialog().textviewer(
            "FIREPLACE • " + label,
            "No desktop browser launcher was found.\n\n"
            "Open this URL on a device with a browser:\n\n" + url
        )

def random_fire():
    import random
    key = random.choice(list(PRESETS))
    launch(key.upper(), PRESETS[key])

def add(label, action):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        sys.argv[0] + "?action=" + action,
        li,
        isFolder=False
    )

def main():
    params = {}
    if len(sys.argv) > 2:
        for part in sys.argv[2].lstrip("?").split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k] = urllib.parse.unquote(v)

    action = params.get("action")

    if action == "random":
        random_fire()
        return

    if action in PRESETS:
        launch(action.upper(), PRESETS[action])
        return

    if action == "about":
        xbmcgui.Dialog().textviewer(
            "FIREPLACE",
            "🔥 FIREPLACE\n\n"
            "A tiny Kodi ambience launcher made for low-storage setups.\n\n"
            "Instead of bundling huge fireplace videos inside the addon, "
            "FIREPLACE opens web searches for the selected ambience.\n\n"
            "Perfect for a TV + Raspberry Pi setup."
        )
        return

    xbmcplugin.setPluginCategory(HANDLE, "FIREPLACE")
    xbmcplugin.setContent(HANDLE, "videos")

    add("🪵  CRACKLING FIRE", "crackling")
    add("🔥  ROARING FIRE", "roaring")
    add("🌙  MIDNIGHT FIRE", "midnight")
    add("🌧️  FIRE + RAIN", "rain")
    add("❄️  WINTER FIRE", "winter")
    add("🏕️  CAMPFIRE", "campfire")
    add("🎲  RANDOM FIRE", "random")
    add("ℹ️  ABOUT", "about")

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    main()
