# -*- coding: utf-8 -*-
"""
Text Browser for Kodi
----------------------
A basic linear text web browser. Fetches a page, strips scripts/styles/tags,
shows the visible text, and lets you pick a link to follow. No JS, no CSS,
no images -- just text. Inspired by the old "script.web.viewer" addon.
"""
import json
import re
import sys
import traceback
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonId()
ADDON_NAME = ADDON.getAddonInfo("name")

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "TextBrowser-Kodi/1.0"
)

MEDIA_EXTENSIONS = (
    ".mp3", ".mp4", ".mkv", ".avi", ".webm", ".m4a",
    ".flac", ".wav", ".ogg", ".mov", ".m3u8",
)

BACK_LABEL = "[COLOR yellow]<< Back[/COLOR]"
ENTER_URL_LABEL = "[COLOR cyan]Enter URL...[/COLOR]"
BOOKMARKS_LABEL = "[COLOR cyan]Bookmarks...[/COLOR]"
ADD_BOOKMARK_LABEL = "[COLOR cyan]Bookmark this page[/COLOR]"
RELOAD_LABEL = "[COLOR cyan]Reload page[/COLOR]"
EXIT_LABEL = "[COLOR red]Exit[/COLOR]"
LINK_PREFIX = "[COLOR lightblue]> [/COLOR]"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, msg), level)


def notify(msg, icon=xbmcgui.NOTIFICATION_INFO, time=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, time)


def get_profile_dir():
    try:
        path = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    except AttributeError:
        path = xbmc.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def bookmarks_path():
    return get_profile_dir() + "bookmarks.json"


def load_bookmarks():
    path = bookmarks_path()
    if not xbmcvfs.exists(path):
        return []
    try:
        f = xbmcvfs.File(path)
        data = f.read()
        f.close()
        return json.loads(data) if data else []
    except Exception:
        log("Failed to read bookmarks:\n" + traceback.format_exc(), xbmc.LOGERROR)
        return []


def save_bookmarks(bookmarks):
    try:
        f = xbmcvfs.File(bookmarks_path(), "w")
        f.write(json.dumps(bookmarks))
        f.close()
    except Exception:
        log("Failed to save bookmarks:\n" + traceback.format_exc(), xbmc.LOGERROR)


def normalize_url(url):
    url = url.strip()
    if not url:
        return url
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "https://" + url
    return url


def looks_like_media(url):
    path = urllib.parse.urlparse(url).path.lower()
    return path.endswith(MEDIA_EXTENSIONS)


class PageParser(HTMLParser):
    """Pulls out a title, plain-text body, and an ordered list of links."""

    SKIP_TAGS = {"script", "style", "head", "noscript", "template", "svg"}
    BLOCK_TAGS = {
        "p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6",
        "section", "article", "header", "footer", "table", "ul", "ol", "blockquote",
    }

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title = ""
        self._in_title = False
        self._skip_depth = 0
        self._current_href = None
        self._text_parts = []
        self.links = []  # list of dicts: {"text": ..., "href": ...}

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP_TAGS:
            self._skip_depth += 1
            return
        if tag == "title":
            self._in_title = True
        if tag in self.BLOCK_TAGS:
            self._text_parts.append("\n")
        if tag == "a":
            href = dict(attrs).get("href")
            if href and not href.strip().lower().startswith(("javascript:", "#", "mailto:")):
                self._current_href = href.strip()
                self._text_parts.append(" \u00ab")  # marks link start visually

    def handle_endtag(self, tag):
        if tag in self.SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)
            return
        if tag == "title":
            self._in_title = False
        if tag == "a" and self._current_href:
            self._text_parts.append("\u00bb ")
            self._current_href = None
        if tag in self.BLOCK_TAGS:
            self._text_parts.append("\n")

    def handle_data(self, data):
        if self._in_title:
            self.title += data
            return
        if self._skip_depth:
            return
        text = data.strip("\n\r")
        if not text.strip():
            if text:
                self._text_parts.append(" ")
            return
        self._text_parts.append(text)
        if self._current_href:
            link_text = " ".join(text.split()) or self._current_href
            self.links.append({"text": link_text, "href": self._current_href})

    def get_text(self):
        raw = "".join(self._text_parts)
        raw = re.sub(r"[ \t]+", " ", raw)
        raw = re.sub(r"\n[ \t]*\n+", "\n\n", raw)
        raw = re.sub(r" *\n *", "\n", raw)
        return raw.strip()


def fetch_page(url):
    timeout = ADDON.getSettingInt("timeout") or 10
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        final_url = resp.geturl()
        content_type = resp.headers.get("Content-Type", "")
        raw = resp.read()
    charset = "utf-8"
    m = re.search(r"charset=([\w-]+)", content_type or "", re.I)
    if m:
        charset = m.group(1)
    try:
        html_text = raw.decode(charset, errors="replace")
    except LookupError:
        html_text = raw.decode("utf-8", errors="replace")
    return final_url, html_text, content_type


def dedupe_links(links):
    seen = set()
    result = []
    for link in links:
        key = (link["text"], link["href"])
        if key in seen:
            continue
        seen.add(key)
        result.append(link)
    return result


def play_media(url):
    if xbmcgui.Dialog().yesno(ADDON_NAME, "This link looks like a media file.\nPlay it?"):
        xbmc.Player().play(url)
        return True
    return False


def build_menu(page_title, links, has_history, current_url):
    items = []
    actions = []

    items.append(RELOAD_LABEL)
    actions.append(("reload", None))

    if has_history:
        items.append(BACK_LABEL)
        actions.append(("back", None))

    items.append(ENTER_URL_LABEL)
    actions.append(("enter_url", None))

    items.append(BOOKMARKS_LABEL)
    actions.append(("bookmarks", None))

    items.append(ADD_BOOKMARK_LABEL)
    actions.append(("add_bookmark", current_url))

    for link in links:
        label = LINK_PREFIX + link["text"][:90]
        items.append(label)
        actions.append(("follow", link["href"]))

    items.append(EXIT_LABEL)
    actions.append(("exit", None))

    return items, actions


def choose_bookmark():
    bookmarks = load_bookmarks()
    if not bookmarks:
        notify("No bookmarks saved yet")
        return None
    labels = ["{}  [COLOR grey]({})[/COLOR]".format(b["title"] or b["url"], b["url"]) for b in bookmarks]
    labels.append("[COLOR red]Cancel[/COLOR]")
    idx = xbmcgui.Dialog().select("Bookmarks", labels)
    if idx == -1 or idx == len(labels) - 1:
        return None
    return bookmarks[idx]["url"]


def add_bookmark(url, title):
    bookmarks = load_bookmarks()
    if any(b["url"] == url for b in bookmarks):
        notify("Already bookmarked")
        return
    bookmarks.append({"url": url, "title": title or url})
    save_bookmarks(bookmarks)
    notify("Bookmarked")


def ask_for_url(default=""):
    kb_url = xbmcgui.Dialog().input("Enter a URL", defaultt=default, type=xbmcgui.INPUT_ALPHANUM)
    if not kb_url:
        return None
    return normalize_url(kb_url)


def load_and_show(url):
    """Fetch + parse a URL, show it, return the (possibly redirected) url or None to stop."""
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Loading {}".format(url))
    try:
        if progress.iscanceled():
            return None
        final_url, html_text, content_type = fetch_page(url)
    except urllib.error.HTTPError as e:
        progress.close()
        notify("HTTP error {}: {}".format(e.code, url), xbmcgui.NOTIFICATION_ERROR)
        return None
    except urllib.error.URLError as e:
        progress.close()
        notify("Could not reach: {}".format(url), xbmcgui.NOTIFICATION_ERROR)
        return None
    except Exception:
        progress.close()
        log("Fetch failed:\n" + traceback.format_exc(), xbmc.LOGERROR)
        notify("Failed to load page", xbmcgui.NOTIFICATION_ERROR)
        return None
    finally:
        if not progress.iscanceled():
            progress.close()

    if "text/html" not in (content_type or "") and "<html" not in html_text[:500].lower():
        if looks_like_media(final_url):
            play_media(final_url)
            return "__STAY__"

    parser = PageParser()
    try:
        parser.feed(html_text)
    except Exception:
        log("Parse failed:\n" + traceback.format_exc(), xbmc.LOGERROR)

    max_chars = ADDON.getSettingInt("max_chars") or 8000
    body_text = parser.get_text()
    title = " ".join(parser.title.split()) or final_url
    display_text = body_text[:max_chars]
    if len(body_text) > max_chars:
        display_text += "\n\n[...truncated...]"

    if not display_text.strip():
        display_text = "(No readable text found on this page)"

    xbmcgui.Dialog().textviewer("{} - {}".format(ADDON_NAME, title), display_text)

    links = dedupe_links(parser.links)
    return final_url, title, links


def run():
    history = []
    current_url = normalize_url(ADDON.getSetting("homepage")) or "https://motherfuckingwebsite.com"

    picked = ask_for_url(default=current_url)
    if picked:
        current_url = picked

    page_title = ""
    links = []

    while True:
        result = load_and_show(current_url)
        if result is None:
            if not history:
                break
            current_url = history.pop()
            continue
        if result == "__STAY__":
            if not history:
                break
            current_url = history.pop()
            continue

        final_url, page_title, links = result
        if final_url != current_url:
            current_url = final_url

        items, actions = build_menu(page_title, links, bool(history), current_url)
        idx = xbmcgui.Dialog().select("{}  [COLOR grey]{}[/COLOR]".format(page_title, current_url), items)

        if idx == -1:
            break

        action, payload = actions[idx]

        if action == "exit":
            break
        elif action == "reload":
            continue
        elif action == "back":
            if history:
                current_url = history.pop()
            continue
        elif action == "enter_url":
            new_url = ask_for_url(default=current_url)
            if new_url:
                history.append(current_url)
                current_url = new_url
            continue
        elif action == "bookmarks":
            chosen = choose_bookmark()
            if chosen:
                history.append(current_url)
                current_url = chosen
            continue
        elif action == "add_bookmark":
            add_bookmark(current_url, page_title)
            continue
        elif action == "follow":
            target = urllib.parse.urljoin(current_url, payload)
            if looks_like_media(target):
                if play_media(target):
                    continue
                else:
                    continue
            history.append(current_url)
            current_url = target
            continue


if __name__ == "__main__":
    try:
        run()
    except Exception:
        log("Unhandled error:\n" + traceback.format_exc(), xbmc.LOGERROR)
        notify("Text Browser crashed - check the log", xbmcgui.NOTIFICATION_ERROR)
