import sys
import random
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])

CURIOSITIES = [
    ("The Moon is slowly moving away", "The Moon drifts away from Earth by roughly 3.8 cm per year."),
    ("Bananas are berries", "Botanically, bananas qualify as berries, while strawberries do not."),
    ("Octopuses have three hearts", "Two hearts move blood toward the gills, while the third pumps it around the body."),
    ("A day on Venus is extremely long", "Venus rotates so slowly that one rotation takes longer than its trip around the Sun."),
    ("Wombat geometry", "Wombats are famous for producing roughly cube-shaped droppings."),
    ("Your fingerprints form before birth", "The broad pattern of fingerprints develops before a person is born."),
    ("There are clouds on Titan", "Saturn's moon Titan has a thick atmosphere and a methane-based weather cycle."),
    ("Lightning can be hotter than the Sun's surface", "A lightning channel can reach temperatures several times hotter than the Sun's visible surface."),
    ("Sharks are ancient", "Sharks appeared hundreds of millions of years before the first dinosaurs."),
    ("A day on Jupiter is short", "Jupiter rotates once in roughly ten hours, despite being the largest planet."),
    ("Honey can last a very long time", "Properly stored honey is remarkably resistant to spoilage because of its chemistry."),
    ("The Eiffel Tower changes height", "Its metal expands in warm weather and contracts when temperatures fall."),
]

def item(label, path=None, playable=False):
    li = xbmcgui.ListItem(label)
    if playable:
        li.setProperty("IsPlayable", "true")
    return li

def show_curiosity():
    title, body = random.choice(CURIOSITIES)
    dialog = xbmcgui.Dialog()
    dialog.ok(f"✦ {title}", body + "\n\nPress OK for another curiosity.")

def main():
    # Each directory refresh produces a fresh selection.
    xbmcplugin.setPluginCategory(HANDLE, "TITIN")
    xbmcplugin.setContent(HANDLE, "files")

    actions = [
        ("🌀 RANDOM CURIOSITY", "curiosity"),
        ("🎲 SURPRISE ME", "curiosity"),
        ("📚 BROWSE ALL CURIOSITIES", "all"),
    ]

    for label, action in actions:
        li = item(label)
        url = sys.argv[0] + "?action=" + action
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)

    params = {}
    if len(sys.argv) > 2:
        for part in sys.argv[2].lstrip("?").split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k] = v

    if params.get("action") == "curiosity":
        show_curiosity()
    elif params.get("action") == "all":
        for title, body in CURIOSITIES:
            xbmcgui.Dialog().ok(f"✦ {title}", body)

if __name__ == "__main__":
    main()
