# -*- coding: utf-8 -*-
import sys
import re
import json
import html
import urllib.parse
import urllib.request
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
UA = "Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 Kodi DUCK/2.0"
HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/json",
    "Referer": "https://duckduckgo.com/"
}

def add_folder(label, action):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, BASE + "?action=" + action, li, True)

def fetch(url, headers=None):
    req = urllib.request.Request(url, headers=headers or HEADERS)
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read().decode("utf-8", "replace")

def prompt(title, default=""):
    return xbmcgui.Dialog().input(
        title, defaultt=default, type=xbmcgui.INPUT_ALPHANUM
    )

def clean(text):
    text = re.sub(r"<[^>]+>", "", text)
    return html.unescape(text).strip()

def web_search(query):
    try:
        url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote_plus(query)
        data = fetch(url, {
            "User-Agent": UA,
            "Accept": "text/html",
            "Referer": "https://html.duckduckgo.com/"
        })
        results = re.findall(
            r'<a[^>]+class=["\']result__a["\'][^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            data, re.S | re.I
        )
        if not results:
            xbmcgui.Dialog().ok("DUCK", "No web results found.")
            return
        for href, title in results[:30]:
            title = clean(title)
            href = html.unescape(href)
            li = xbmcgui.ListItem(label=title)
            u = BASE + "?action=open&url=" + urllib.parse.quote(href, safe="")
            xbmcplugin.addDirectoryItem(HANDLE, u, li, False)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().ok("DUCK", "Web search failed:\n\n" + str(e))

def get_vqd(query):
    url = "https://duckduckgo.com/?q=" + urllib.parse.quote_plus(query) + "&iax=images&ia=images"
    data = fetch(url)
    patterns = [
        r"vqd='([^']+)'",
        r'vqd="([^"]+)"',
        r'"vqd"\s*:\s*"([^"]+)"',
        r'vqd=([0-9-]+)'
    ]
    for pattern in patterns:
        m = re.search(pattern, data)
        if m:
            return m.group(1)
    raise RuntimeError("DuckDuckGo did not provide an image-search token (vqd).")

def image_search(query):
    try:
        vqd = get_vqd(query)
        params = {
            "q": query,
            "o": "json",
            "l": "us-en",
            "vqd": vqd,
            "p": "-1"
        }
        url = "https://duckduckgo.com/i.js?" + urllib.parse.urlencode(params)
        raw = fetch(url, {
            "User-Agent": UA,
            "Accept": "application/json,text/plain,*/*",
            "Referer": "https://duckduckgo.com/"
        })
        payload = json.loads(raw)
        results = payload.get("results", [])
        if not results:
            xbmcgui.Dialog().ok("DUCK", "No images found.")
            return

        xbmcplugin.setContent(HANDLE, "images")

        for i, result in enumerate(results[:50]):
            image = result.get("image") or result.get("thumbnail")
            thumb = result.get("thumbnail") or image
            title = clean(result.get("title", "Image " + str(i + 1)))
            source = result.get("url", "")
            if not image:
                continue

            li = xbmcgui.ListItem(label=title)
            li.setArt({
                "thumb": thumb,
                "icon": thumb,
                "poster": thumb
            })
            li.setInfo("pictures", {
                "title": title,
                "studio": urllib.parse.urlparse(source).netloc
            })

            # The full image URL is the plugin item target.
            # Kodi can hand it to its built-in image viewer.
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(HANDLE, image, li, False)

        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().ok(
            "DUCK IMAGE SEARCH",
            "Image search failed.\n\n" + str(e)
        )

def main():
    args = sys.argv[2] if len(sys.argv) > 2 else ""
    params = dict(urllib.parse.parse_qsl(args.lstrip("?")))
    action = params.get("action", "")

    if not action:
        add_folder("🦆 Search the Web", "web")
        add_folder("🖼️ Search Images", "images")
        add_folder("🔗 Open URL", "url")
        add_folder("ℹ️ About DUCK", "about")
        xbmcplugin.endOfDirectory(HANDLE)

    elif action == "web":
        q = prompt("DuckDuckGo Web Search")
        if q:
            web_search(q)

    elif action == "images":
        q = prompt("DuckDuckGo Image Search")
        if q:
            image_search(q)

    elif action == "url":
        q = prompt("Enter URL", "https://")
        if q:
            xbmcgui.Dialog().ok(
                "DUCK",
                "DUCK 2.0 is focused on native image browsing.\n\n"
                "URL: " + q
            )

    elif action == "open":
        # Kept for compatibility with old DUCK web result URLs.
        url = params.get("url", "")
        if url:
            xbmcgui.Dialog().ok("DUCK", url)

    elif action == "about":
        xbmcgui.Dialog().ok(
            "DUCK 2.0.0",
            "🦆 DUCK\n\n"
            "Web search: DuckDuckGo HTML\n"
            "Images: DuckDuckGo image results\n\n"
            "Images are presented as native Kodi picture items.\n"
            "No external browser is used for image browsing."
        )

if __name__ == "__main__":
    main()
