VOID Kodi Add-on v1.0.0

A lightweight curiosity hub for Kodi.

WWV SIMULATOR
The WWV Simulator entry launches:
https://wwv.mcodes.org/

VOID does not copy or redistribute the simulator's audio/assets.
It opens the original site so the simulation can run in its intended
JavaScript/browser environment.

On Linux, VOID tries xdg-open, gio, and sensible-browser.
If no browser launcher is available, it displays the URL instead.

Built for Kodi Omega / Python 3.
