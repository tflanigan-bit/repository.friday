# -*- coding: utf-8 -*-
import sys
import random
import subprocess
import shutil
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
WWV_URL = "https://wwv.mcodes.org/"

def item(label, action, info=None):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "false")
    if info:
        li.setInfo("video", {"title": label, "plot": info})
    url = sys.argv[0] + "?action=" + action
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

def open_url(url):
    # Try common Linux desktop URL openers first.
    for cmd in ("xdg-open", "gio", "sensible-browser"):
        if shutil.which(cmd):
            try:
                subprocess.Popen([cmd, url],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
                return True
            except Exception:
                pass
    return False

def show_wwv():
    opened = open_url(WWV_URL)
    if opened:
        xbmcgui.Dialog().notification(
            "VOID • WWV",
            "WWV Simulator opened in your browser.",
            xbmcgui.NOTIFICATION_INFO,
            3500
        )
    else:
        xbmcgui.Dialog().textviewer(
            "WWV SIMULATOR",
            "VOID could not find a desktop browser launcher.\n\n"
            "Open this address on a device with a browser:\n\n" + WWV_URL
        )

def about_wwv():
    xbmcgui.Dialog().textviewer(
        "WWV SIMULATOR",
        "A browser-based simulation of the audible portions of WWV and WWVH.\n\n"
        "It uses your computer/device time and audio samples rather than "
        "rebroadcasting the real radio transmissions.\n\n"
        "WWV: Fort Collins, Colorado\n"
        "WWVH: Kekaha, Hawaii\n\n"
        "Open the simulator:\n" + WWV_URL
    )

def placeholder(title):
    xbmcgui.Dialog().ok(
        "VOID • " + title,
        "This chamber is still being assembled.\n\n"
        "The signal is there. We just haven't opened the door yet. :3"
    )

def unknown():
    things = [
        "You found a room that wasn't on the blueprint.",
        "The void noticed you first.",
        "SIGNAL ACQUIRED: probably.",
        "There is no spoon. There is, however, a Kodi addon.",
        "A distant tone repeats once every second.",
        "Someone labeled this box 'DO NOT OPEN' and then installed Kodi on it."
    ]
    xbmcgui.Dialog().ok("VOID • UNKNOWN", random.choice(things))

def main():
    params = {}
    if len(sys.argv) > 2:
        for part in sys.argv[2].lstrip("?").split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k] = v

    action = params.get("action")

    if action == "wwv":
        show_wwv()
        return
    if action == "wwv_about":
        about_wwv()
        return
    if action == "signals":
        placeholder("SIGNALS")
        return
    if action == "artifacts":
        placeholder("ARTIFACTS")
        return
    if action == "lostmedia":
        placeholder("LOST MEDIA")
        return
    if action == "lore":
        placeholder("LORE")
        return
    if action == "unknown":
        unknown()
        return

    xbmcplugin.setPluginCategory(HANDLE, "VOID")
    xbmcplugin.setContent(HANDLE, "files")

    item("📡  WWV SIMULATOR", "wwv",
         "Launch the WWV/WWVH audio simulator in your browser.")
    item("ℹ️  About WWV", "wwv_about",
         "What the simulator is and how it works.")
    item("📻  SIGNALS", "signals")
    item("🖼️  ARTIFACTS", "artifacts")
    item("📼  LOST MEDIA", "lostmedia")
    item("🧠  LORE", "lore")
    item("🎲  UNKNOWN", "unknown")

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    main()
