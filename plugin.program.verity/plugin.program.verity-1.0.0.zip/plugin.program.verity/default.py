# -*- coding: utf-8 -*-
import sys
import random
import urllib.parse
import urllib.request
import json

import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])

CLAIMS = [
    ("A day on Venus is longer than a year on Venus.",
     "TRUE", "Venus rotates once about every 243 Earth days, while it orbits the Sun in about 225 Earth days."),
    ("Lightning never strikes the same place twice.",
     "FALSE", "Lightning can strike the same location repeatedly, especially tall or exposed structures."),
    ("The Great Wall of China is visible from the Moon with the naked eye.",
     "FALSE", "The claim is a popular myth. The wall is not reliably visible from the Moon without optical aid."),
    ("Octopuses have three hearts.",
     "TRUE", "Octopuses have three hearts: two pump blood toward the gills and one pumps it through the body."),
    ("A goldfish has only a three-second memory.",
     "FALSE", "Goldfish can learn and retain associations for much longer than a few seconds.")
]

HISTORY = [
    ("The first modern Olympic Games were held in 1896.",
     "TRUE", "The first modern Olympic Games took place in Athens in 1896."),
    ("The printing press was invented in the 20th century.",
     "FALSE", "Johannes Gutenberg's movable-type printing press dates to 15th-century Europe.")
]

SCIENCE = [
    ("Sound can travel through a vacuum.",
     "FALSE", "Sound needs a medium such as air, water, or a solid to propagate."),
    ("Water expands when it freezes.",
     "TRUE", "Ice occupies more volume than the same mass of liquid water because of its crystal structure.")
]

def add_item(label, action, folder=False):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        sys.argv[0] + "?action=" + urllib.parse.quote(action),
        li,
        isFolder=folder
    )

def show_claim(claim):
    text, verdict, explanation = claim
    xbmcgui.Dialog().textviewer(
        "VERITY • " + verdict,
        "CLAIM\n" + text + "\n\n"
        "VERDICT\n" + verdict + "\n\n"
        "WHY\n" + explanation
    )

def random_claim():
    show_claim(random.choice(CLAIMS + HISTORY + SCIENCE))

def browse_claims(dataset, title):
    for claim, verdict, explanation in dataset:
        li = xbmcgui.ListItem(label=("✓ " if verdict == "TRUE" else "✗ ") + claim)
        li.setInfo("video", {"title": claim, "plot": explanation})
        url = sys.argv[0] + "?action=claim&claim=" + urllib.parse.quote(claim)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def find_claim(claim_text):
    for claim in CLAIMS + HISTORY + SCIENCE:
        if claim[0] == claim_text:
            return claim
    return None

def search_web():
    keyboard = xbmcgui.Dialog().input(
        "VERIFY SOMETHING",
        "",
        type=xbmcgui.INPUT_ALPHANUM
    )
    if not keyboard:
        return

    # Lightweight DuckDuckGo HTML search. No external Python packages.
    query = urllib.parse.quote(keyboard + " fact check")
    url = "https://html.duckduckgo.com/html/?q=" + query

    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0 VERITY Kodi Add-on"}
        )
        data = urllib.request.urlopen(req, timeout=8).read().decode("utf-8", "ignore")
        # Keep this intentionally simple: show the search page URL rather than
        # scraping/copying search-result text into Kodi.
        xbmcgui.Dialog().textviewer(
            "VERITY • WEB SEARCH",
            "A web search was prepared for:\n\n" + keyboard +
            "\n\nOpen this search in a browser:\n\n" +
            "https://duckduckgo.com/?q=" + query
        )
    except Exception:
        xbmcgui.Dialog().textviewer(
            "VERITY • WEB SEARCH",
            "The web search could not be reached from Kodi.\n\n"
            "Search manually for:\n" + keyboard + " fact check"
        )

def main():
    params = {}
    if len(sys.argv) > 2:
        for part in sys.argv[2].lstrip("?").split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k] = urllib.parse.unquote(v)

    action = params.get("action")

    if action == "claim":
        claim = find_claim(params.get("claim", ""))
        if claim:
            show_claim(claim)
        return

    if action == "random":
        random_claim()
        return

    if action == "search":
        search_web()
        return

    if action == "history":
        browse_claims(HISTORY, "HISTORICAL")
        return

    if action == "science":
        browse_claims(SCIENCE, "SCIENCE & SPACE")
        return

    if action == "internet":
        xbmcgui.Dialog().ok(
            "VERITY • INTERNET ODDITIES",
            "This chamber is reserved for strange web claims.\n\n"
            "More sources coming in a future version."
        )
        return

    if action == "unverified":
        xbmcgui.Dialog().ok(
            "VERITY • UNVERIFIED",
            "Not every claim has a verdict yet.\n\n"
            "UNVERIFIED does not mean TRUE or FALSE — "
            "it means more evidence is needed."
        )
        return

    xbmcplugin.setPluginCategory(HANDLE, "VERITY")
    xbmcplugin.setContent(HANDLE, "files")

    add_item("🔎  VERIFY SOMETHING", "search")
    add_item("🧠  RANDOM CLAIM", "random")
    add_item("📜  HISTORICAL", "history", True)
    add_item("🛰️  SCIENCE & SPACE", "science", True)
    add_item("🕳️  INTERNET ODDITIES", "internet")
    add_item("🎲  TRUST THE VOID", "random")
    add_item("⚠️  UNVERIFIED", "unverified")

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    main()
