VERITY Kodi Add-on v1.0.0
The Truth Terminal

VERITY provides a small offline collection of claims with simple TRUE/FALSE
verdicts and explanations, plus a lightweight web-search handoff.

The web-search feature opens a DuckDuckGo search URL rather than copying
search-result pages into the addon.

Built for Kodi's Python 3 addon environment.
