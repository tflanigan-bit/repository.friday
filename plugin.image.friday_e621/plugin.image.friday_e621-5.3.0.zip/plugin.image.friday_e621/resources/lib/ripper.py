# -*- coding: utf-8 -*-
"""Streaming ZIP ripper. Downloads to temp files then appends to the archive,
so a Raspberry Pi 3 never has to hold a gallery in RAM."""

import json
import os
import re
import shutil
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor

from . import e621_client

SAFE_RE = re.compile(r"[^A-Za-z0-9._-]+")


def safe_name(text, limit=60):
    text = SAFE_RE.sub("_", (text or "").strip())
    return text.strip("_")[:limit] or "untitled"


def zip_stamp(prefix):
    return "%s_%s.zip" % (safe_name(prefix, 48), time.strftime("%Y%m%d-%H%M%S"))


def entry_name(post, quality="original"):
    url = e621_client.file_url(post, quality) or ""
    ext = (post.get("file") or {}).get("ext") or url.rsplit(".", 1)[-1] or "jpg"
    artist = safe_name(e621_client.post_artists(post)[0], 40)
    return "%s/%s_%s.%s" % (artist, post.get("id"), artist, ext)


def manifest_entry(post, quality="original"):
    tags = post.get("tags") or {}
    return {
        "id": post.get("id"),
        "url": "https://e621.net/posts/%s" % post.get("id"),
        "file": e621_client.file_url(post, quality),
        "md5": (post.get("file") or {}).get("md5"),
        "ext": (post.get("file") or {}).get("ext"),
        "rating": post.get("rating"),
        "score": (post.get("score") or {}).get("total"),
        "fav_count": post.get("fav_count"),
        "created_at": post.get("created_at"),
        "sources": post.get("sources") or [],
        "artist": tags.get("artist") or [],
        "character": tags.get("character") or [],
        "copyright": tags.get("copyright") or [],
        "species": tags.get("species") or [],
        "general": tags.get("general") or [],
        "meta": tags.get("meta") or [],
    }


class Ripper(object):
    """Rips an iterable of post-batches into a single ZIP file."""

    def __init__(self, user_agent, quality="original", threads=4, timeout=30,
                 retries=2, write_manifest=True, log=None, compress=False):
        self.user_agent = user_agent
        self.quality = quality
        self.threads = max(1, min(int(threads), 8))
        self.timeout = int(timeout)
        self.retries = int(retries)
        self.write_manifest = bool(write_manifest)
        self.compress = bool(compress)
        self._log = log or (lambda msg: None)
        self.cancelled = False

    # ------------------------------------------------------------- internals

    def _fetch(self, post, tmpdir):
        url = e621_client.file_url(post, self.quality)
        if not url:
            return None
        dest = os.path.join(tmpdir, "%s.part" % post.get("id"))
        attempt = 0
        while True:
            attempt += 1
            try:
                req = urllib.request.Request(url, headers={"User-Agent": self.user_agent})
                with urllib.request.urlopen(req, timeout=self.timeout) as resp, \
                        open(dest, "wb") as handle:
                    shutil.copyfileobj(resp, handle, 64 * 1024)
                return dest
            except (urllib.error.URLError, urllib.error.HTTPError, OSError) as exc:
                if attempt <= self.retries:
                    time.sleep(1.0 * attempt)
                    continue
                self._log("Failed post %s: %s" % (post.get("id"), exc))
                try:
                    if os.path.exists(dest):
                        os.remove(dest)
                except OSError:
                    pass
                return None

    # ------------------------------------------------------------------- run

    def rip(self, batches, zip_path, progress=None, total_hint=0, label=""):
        """`batches` yields lists of posts. `progress` is a callable
        (done, total, text) -> bool, returning False to cancel."""
        mode = zipfile.ZIP_DEFLATED if self.compress else zipfile.ZIP_STORED
        tmpdir = tempfile.mkdtemp(prefix="friday_e621_")
        done = failed = 0
        manifest = []
        seen = set()
        try:
            with zipfile.ZipFile(zip_path, "w", mode, allowZip64=True) as archive:
                for posts in batches:
                    posts = [p for p in posts if p.get("id") not in seen]
                    for p in posts:
                        seen.add(p.get("id"))
                    if not posts:
                        continue
                    with ThreadPoolExecutor(max_workers=self.threads) as pool:
                        results = list(pool.map(lambda p: (p, self._fetch(p, tmpdir)), posts))
                    for post, path in results:
                        if path and os.path.exists(path):
                            try:
                                archive.write(path, entry_name(post, self.quality))
                                manifest.append(manifest_entry(post, self.quality))
                                done += 1
                            except OSError as exc:
                                failed += 1
                                self._log("Zip write failed for %s: %s" % (post.get("id"), exc))
                            finally:
                                try:
                                    os.remove(path)
                                except OSError:
                                    pass
                        else:
                            failed += 1
                        if progress:
                            total = total_hint or len(seen)
                            text = "%s\nSaved %s | failed %s" % (label, done, failed)
                            if progress(done, total, text) is False:
                                self.cancelled = True
                                break
                    if self.cancelled:
                        break
                if self.write_manifest and manifest:
                    archive.writestr(
                        "friday_manifest.json",
                        json.dumps(manifest, indent=2, ensure_ascii=False),
                    )
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
        return {"saved": done, "failed": failed, "cancelled": self.cancelled, "zip": zip_path}
