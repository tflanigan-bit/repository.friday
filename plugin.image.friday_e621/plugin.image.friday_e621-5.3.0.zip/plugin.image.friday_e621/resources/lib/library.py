# -*- coding: utf-8 -*-
"""Local library index.

Walks the download folder, looks inside every Friday ZIP (via Kodi's zip:// VFS
so it works on smb:// / nfs:// shares too), and builds an index of every picture
already on disk. Used by the "All pics" viewer and to flag posts as downloaded
while browsing.
"""

import json
import os
import urllib.parse

import xbmcvfs

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")
INDEX_VERSION = 2


def zip_vfs(archive_path, entry=""):
    """Kodi VFS path pointing inside a ZIP."""
    quoted = urllib.parse.quote(archive_path, safe="")
    entry = entry.lstrip("/")
    return "zip://%s/%s" % (quoted, entry)


def _join(base, name):
    if "://" in base:
        return base.rstrip("/") + "/" + name
    return os.path.join(base, name)


def _is_image(name):
    return name.lower().endswith(IMAGE_EXT)


def post_id_from_name(name):
    stem = os.path.basename(name).split(".")[0]
    head = stem.split("_")[0]
    return int(head) if head.isdigit() else None


def _walk_zip(archive_path, prefix=""):
    """Recursively yield entry paths inside a ZIP through the VFS."""
    try:
        dirs, files = xbmcvfs.listdir(zip_vfs(archive_path, prefix))
    except Exception:
        return
    for name in files or []:
        yield (prefix + name) if prefix else name
    for sub in dirs or []:
        child = "%s%s/" % (prefix, sub)
        for item in _walk_zip(archive_path, child):
            yield item


def _read_manifest(archive_path):
    handle = None
    try:
        path = zip_vfs(archive_path, "friday_manifest.json")
        if not xbmcvfs.exists(path):
            return {}
        handle = xbmcvfs.File(path)
        raw = handle.read()
        data = json.loads(raw) if raw else []
        return dict((int(e["id"]), e) for e in data if e.get("id") is not None)
    except Exception:
        return {}
    finally:
        if handle:
            try:
                handle.close()
            except Exception:
                pass


def _entry(path, artist, post_id, source="", ext=""):
    return {
        "path": path,
        "artist": artist or "unknown_artist",
        "id": post_id,
        "source": source,
        "ext": ext or os.path.splitext(path)[1].lstrip("."),
    }


def scan(root, progress=None, log=None):
    """Return a fresh index dict for everything under `root`."""
    log = log or (lambda m: None)
    entries = []
    archives = []
    stack = [root]
    seen_dirs = set()

    while stack:
        current = stack.pop()
        if current in seen_dirs:
            continue
        seen_dirs.add(current)
        try:
            dirs, files = xbmcvfs.listdir(current)
        except Exception as exc:
            log("listdir failed on %s: %s" % (current, exc))
            continue
        for sub in dirs or []:
            stack.append(_join(current, sub) + ("/" if "://" in current else ""))
        for name in files or []:
            full = _join(current, name)
            if name.lower().endswith(".zip"):
                archives.append(full)
            elif _is_image(name):
                artist = os.path.basename(current.rstrip("/\\")) or "loose"
                entries.append(_entry(full, artist, post_id_from_name(name)))

    for index, archive in enumerate(archives):
        if progress and progress(index, len(archives), os.path.basename(archive)) is False:
            break
        manifest = _read_manifest(archive)
        for member in _walk_zip(archive):
            if not _is_image(member):
                continue
            post_id = post_id_from_name(member)
            meta = manifest.get(post_id) or {}
            artists = meta.get("artist") or []
            artist = artists[0] if artists else (member.split("/")[0] if "/" in member else "unknown_artist")
            entries.append(_entry(zip_vfs(archive, member), artist, post_id,
                                  source=os.path.basename(archive)))

    # De-dupe: prefer the first hit per post id, keep all id-less files.
    deduped = []
    seen_ids = set()
    for item in entries:
        pid = item.get("id")
        if pid is not None:
            if pid in seen_ids:
                continue
            seen_ids.add(pid)
        deduped.append(item)

    deduped.sort(key=lambda e: (e["artist"].lower(), -(e["id"] or 0)))
    return {
        "version": INDEX_VERSION,
        "root": root,
        "archives": len(archives),
        "entries": deduped,
    }


def load(path):
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            if data.get("version") == INDEX_VERSION:
                return data
    except Exception:
        pass
    return {"version": INDEX_VERSION, "root": "", "archives": 0, "entries": []}


def save(path, data):
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data, handle)
        return True
    except Exception:
        return False


def downloaded_ids(index):
    return set(e["id"] for e in index.get("entries", []) if e.get("id") is not None)


def by_artist(index):
    buckets = {}
    for entry in index.get("entries", []):
        buckets.setdefault(entry["artist"], []).append(entry)
    return buckets


def by_archive(index):
    buckets = {}
    for entry in index.get("entries", []):
        buckets.setdefault(entry.get("source") or "Loose files", []).append(entry)
    return buckets
