# -*- coding: utf-8 -*-
"""Dependency-free e621 API client (urllib only) tuned for Raspberry Pi 3."""

import base64
import json
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://e621.net"
MAX_NUMERIC_PAGE = 750  # e621 refuses numeric paging past this


class E621Error(Exception):
    pass


class E621Client(object):

    def __init__(self, user_agent, login=None, api_key=None, timeout=20,
                 retries=3, backoff=1.5, log=None):
        self.user_agent = user_agent or "FridayE621Grabber/5.0.0 (by tflanigan on e621)"
        self.login = (login or "").strip()
        self.api_key = (api_key or "").strip()
        self.timeout = int(timeout)
        self.retries = int(retries)
        self.backoff = float(backoff)
        self._log = log or (lambda msg: None)
        self._last_call = 0.0

    # ------------------------------------------------------------------ http

    def _headers(self):
        headers = {
            "User-Agent": self.user_agent,
            "Accept": "application/json",
        }
        if self.login and self.api_key:
            raw = ("%s:%s" % (self.login, self.api_key)).encode("utf-8")
            headers["Authorization"] = "Basic " + base64.b64encode(raw).decode("ascii")
        return headers

    def _throttle(self):
        # e621 asks for <= 2 req/sec. Keep a hard floor of 0.55s between calls.
        delta = time.time() - self._last_call
        if delta < 0.55:
            time.sleep(0.55 - delta)
        self._last_call = time.time()

    def request(self, path, params=None):
        url = BASE + path
        if params:
            clean = dict((k, v) for k, v in params.items() if v not in (None, ""))
            url += "?" + urllib.parse.urlencode(clean, doseq=True)

        attempt = 0
        while True:
            attempt += 1
            self._throttle()
            req = urllib.request.Request(url, headers=self._headers())
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    payload = resp.read().decode("utf-8", "replace")
                return json.loads(payload) if payload.strip() else {}
            except urllib.error.HTTPError as exc:
                if exc.code in (429, 500, 502, 503, 504) and attempt <= self.retries:
                    wait = self.backoff ** attempt
                    self._log("HTTP %s on %s - retry %s in %.1fs" % (exc.code, url, attempt, wait))
                    time.sleep(wait)
                    continue
                if exc.code == 401:
                    raise E621Error("401 Unauthorised - check your username / API key in settings.")
                if exc.code == 403:
                    raise E621Error("403 Forbidden - your User-Agent is probably rejected.")
                raise E621Error("HTTP %s from e621: %s" % (exc.code, exc.reason))
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                if attempt <= self.retries:
                    wait = self.backoff ** attempt
                    self._log("Network error %s - retry %s in %.1fs" % (exc, attempt, wait))
                    time.sleep(wait)
                    continue
                raise E621Error("Network error talking to e621: %s" % exc)
            except ValueError as exc:
                raise E621Error("Bad JSON from e621: %s" % exc)

    # ----------------------------------------------------------------- posts

    def posts(self, tags="", limit=60, page=1):
        """One page of posts. `page` may be an int or a token like 'b12345'."""
        data = self.request("/posts.json", {
            "tags": tags,
            "limit": max(1, min(int(limit), 320)),
            "page": page,
        })
        posts = data.get("posts", []) if isinstance(data, dict) else []
        return [p for p in posts if (p.get("file") or {}).get("url")]

    def iter_pages(self, tags="", limit=60, start_page=1, max_pages=0):
        """Yield (page_number, posts) walking a whole search.

        Uses numeric paging, then flips to before-id paging past page 750 so
        huge searches keep working.
        """
        page = start_page
        served = 0
        token = page
        while True:
            posts = self.posts(tags=tags, limit=limit, page=token)
            if not posts:
                return
            served += 1
            yield served, posts
            if max_pages and served >= max_pages:
                return
            page += 1
            if page > MAX_NUMERIC_PAGE:
                lowest = min(p.get("id", 0) for p in posts)
                if not lowest:
                    return
                token = "b%s" % lowest
            else:
                token = page

    def count(self, tags=""):
        """Approximate post count for a search (used for progress bars)."""
        try:
            data = self.request("/counts/posts.json", {"tags": tags})
            return int(((data or {}).get("counts") or {}).get("posts", 0))
        except Exception:
            return 0

    # ------------------------------------------------------------------ tags

    def tag_suggest(self, term, limit=30, fuzzy=True):
        """Fuzzy tag lookup. Wildcards both sides unless the user supplied any."""
        term = (term or "").strip().replace(" ", "_")
        if not term:
            return []
        pattern = term if ("*" in term and not fuzzy) else "*%s*" % term.strip("*")
        data = self.request("/tags.json", {
            "search[name_matches]": pattern,
            "search[order]": "count",
            "search[hide_empty]": "true",
            "limit": max(1, min(int(limit), 100)),
        })
        if isinstance(data, dict):
            data = data.get("tags", [])
        out = []
        for tag in data or []:
            if not isinstance(tag, dict):
                continue
            out.append({
                "name": tag.get("name", ""),
                "count": int(tag.get("post_count") or 0),
                "category": int(tag.get("category") or 0),
            })
        return [t for t in out if t["name"]]

    def related_tags(self, post):
        tags = (post or {}).get("tags") or {}
        merged = []
        for group in ("artist", "character", "copyright", "species", "general"):
            merged.extend(tags.get(group) or [])
        return merged


# ------------------------------------------------------------------ ratings

RATINGS = [("s", "Safe"), ("q", "Questionable"), ("e", "Explicit")]
RATING_NAMES = dict(RATINGS)


def rating_query(active):
    """Build the tag fragment for a set of enabled ratings."""
    active = [r for r, _ in RATINGS if r in (active or [])]
    if not active or len(active) == len(RATINGS):
        return ""
    if len(active) == 1:
        return "rating:%s" % active[0]
    return " ".join("~rating:%s" % r for r in active)


def rating_label(active):
    active = [r for r, _ in RATINGS if r in (active or [])]
    if not active:
        return "[COLOR FFFF5555]none[/COLOR]"
    if len(active) == len(RATINGS):
        return "[COLOR FFFFAA00]S Q E (all)[/COLOR]"
    return " ".join("[COLOR FF44DD44]%s[/COLOR]" % r.upper() for r in active)


# --------------------------------------------------------------------- utils

TAG_CATEGORIES = {
    0: "general", 1: "artist", 3: "copyright",
    4: "character", 5: "species", 6: "invalid",
    7: "meta", 8: "lore",
}


def post_artists(post):
    artists = ((post or {}).get("tags") or {}).get("artist") or []
    artists = [a for a in artists if a not in ("conditional_dnp", "sound_warning")]
    return artists or ["unknown_artist"]


def post_title(post):
    pid = post.get("id", "?")
    artist = ", ".join(post_artists(post)[:2])
    score = ((post.get("score") or {}).get("total"))
    rating = (post.get("rating") or "?").upper()
    return "#%s - %s [%s] (%s)" % (pid, artist, rating, score if score is not None else "-")


def file_url(post, quality="original"):
    file_info = post.get("file") or {}
    sample = post.get("sample") or {}
    if quality == "sample" and sample.get("has") and sample.get("url"):
        return sample["url"]
    return file_info.get("url")


def is_blacklisted(post, blacklist):
    if not blacklist:
        return False
    tags = post.get("tags") or {}
    flat = set()
    for group in tags.values():
        if isinstance(group, list):
            flat.update(group)
    flat.add("rating:%s" % (post.get("rating") or ""))
    return any(term in flat for term in blacklist)
