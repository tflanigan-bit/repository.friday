# Friday e621 Grabber (plugin.image.friday_e621) v5.3.0

Kodi image plugin for e621: tag search, fuzzy tag search, multi-tag builder,
rating switch, custom pagination, ZIP ripping, and a unified viewer for every
picture you have or could have.

## Install
1. Copy `plugin.image.friday_e621.zip` to the Kodi box.
2. Kodi > Add-ons > Install from zip file. (Unknown sources must be ON.)
3. Settings > Account: username + API key (e621.net > Account > Manage API Access).

## Presets
- Eight slots under **Settings > Presets 1-4 / 5-8**. Every slot ships **off**;
  nothing appears in the menu until you flip `enabled`.
- Each slot has: name, tags, ratings (`switch` = follow the global switch, or
  `all` / `s` / `q` / `e` / `sq` / `qe` / `sqe`), and its own page size
  (0 = use the default).
- Enabled presets show up under the root **Presets** menu. Context menu on each
  one: View ALL pics, Rip ALL pages, or turn the preset off without opening
  settings.
- Any browse view has **Save as preset** - pick a slot, name it, and it's
  written into settings and switched on for you.

## Rating switch
- Menu item "Rating switch: S Q E" appears on the root menu, in every browse
  view, in the ALL-pics viewer, and on each post's context menu.
- Multiselect Safe / Questionable / Explicit. One rating -> `rating:x`,
  two -> `~rating:a ~rating:b` (e621's OR syntax), all three -> no filter.
- The switch is remembered in `ratings.json` and applies to browsing, the
  viewer, and every rip.
- **ALL RATINGS ON** and **ALL RATINGS OFF** sit side by side on the root menu.
  ON switches Safe + Questionable + Explicit all on, which sends no `rating:`
  token at all - completely unfiltered. OFF switches all three off; browsing,
  the viewer and rips then refuse to query e621 and show a reminder to pick a
  rating instead of quietly falling back to unfiltered results.
  Browse / viewer views also get "ALL RATINGS for this view", which applies
  only to that container (via the `rovr` URL parameter) and carries through
  its pagination, viewer and rip links.
- Settings > Ratings has the startup defaults, plus **Lock to Safe** which
  overrides the switch (and every preset override) entirely.
- Any explicit `rating:` token you type in a search wins over the switch.

## Pagination
- Page size is per-view: "Change page size" offers 10-320 presets or a custom
  number, and can save the choice as the new default.
- "Jump to page..." for direct navigation, plus Previous / First / Next.
- Header shows `Page 3/128 - 60 per page (7642 posts found)` using the
  `/counts/posts.json` endpoint (turn off with "Show total posts" if you want
  one less API call per view).
- Past page 750 the client automatically flips to before-id paging so deep
  searches keep working.

## ALL pics viewer
- **Viewer > All downloaded pics** - everything indexed on disk, including
  images still inside ZIPs, read through Kodi's `zip://` VFS. No extracting.
- **By artist / By ZIP archive** - same library, bucketed.
- **Everything for a search** - pulls N live pages from e621 and merges them
  with your local copies into one flat, slideshow-ready directory. Downloaded
  posts show with a green `*` and the remote duplicate is hidden.
- **Slideshow** - fires Kodi's SlideShow builtin on the current view.
- **Rebuild index** - rescans the download folder. Runs automatically after
  each rip unless you turn that off.
- Indexing reads `friday_manifest.json` from each ZIP, so artist names and post
  ids survive. Loose image files in the folder get picked up too.
- Because indexing goes through the VFS, an smb:// or nfs:// download folder
  works exactly like a local one.

## Ripping
- **Rip THIS page** / **Rip ALL pages**, capped by the `max_pages` setting
  (0 = unlimited). "Skip posts already in the index" avoids re-downloading.
- ZIPs land as `<query>_YYYYMMDD-HHMMSS.zip`, foldered by artist, with
  `friday_manifest.json` (ids, md5s, full tag groups, scores, sources).
- Cancel any time - the partial ZIP is still a valid archive.

## Pi 3 notes
- 4 threads, ZIP_STORED by default, downloads stream to disk not RAM.
- API hard-throttled to ~2 req/sec.
- "Image shown in Kodi" = `sample` for snappy browsing, downloads stay
  `original`. Keep "Pages to pull into the ALL pics viewer" modest (5-10) on a
  Pi; each page is one API call plus thumbnail loads.

Stdlib only. No third-party Python modules.


## Skin compatibility (Transparency! and similar)
- `icon.png`, `banner.png` and `clearlogo.png` are all true-alpha transparent
  PNGs, and `addon.xml` declares all three asset types plus fanart - skins
  that render addon tiles with translucent panels (Transparency!, and others
  in that family) get proper artwork instead of a flat icon square.
- Every list item also sets `poster`, `banner` and `landscape` art in addition
  to `thumb`/`icon`/`fanart`, falling back to the post's own image where a
  dedicated asset doesn't apply - skins that pull from those art types for
  their tile/panel layouts still get a picture instead of a blank space.
- No skin-specific code or dependency is used; this is plain listitem art, so
  it works the same under Estuary, Arctic Zephyr, Transparency! or anything
  else.
