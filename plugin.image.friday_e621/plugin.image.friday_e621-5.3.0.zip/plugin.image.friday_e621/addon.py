# -*- coding: utf-8 -*-
"""Friday e621 Grabber - Kodi image plugin. v5.1.0

Tag search / fuzzy tag search / multi-tag builder / rating switch /
custom pagination / ZIP ripping / unified viewer for every pic, local or remote.
"""

import json
import math
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import e621_client, library, ripper
from resources.lib.e621_client import E621Client, E621Error

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
VERSION = ADDON.getAddonInfo("version")
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0]
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
SEARCH_DB = os.path.join(PROFILE, "saved_searches.json")
HISTORY_DB = os.path.join(PROFILE, "history.json")
BUILDER_DB = os.path.join(PROFILE, "builder.json")
RATINGS_DB = os.path.join(PROFILE, "ratings.json")
INDEX_DB = os.path.join(PROFILE, "library_index.json")

CAT_COLOURS = {1: "FFFF8C00", 3: "FFDD00DD", 4: "FF00AA00", 5: "FF00AAAA", 7: "FFAAAAAA"}
PAGE_SIZE_CHOICES = [10, 20, 30, 40, 60, 80, 100, 160, 200, 240, 320]
PRESET_SLOTS = 8
RATING_MODES = ["switch", "all", "s", "q", "e", "sq", "sq" + "e", "qe"]


# --------------------------------------------------------------------- helpers

def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


def notify(message, heading=None, icon=xbmcgui.NOTIFICATION_INFO, ms=4000):
    xbmcgui.Dialog().notification(heading or ADDON_NAME, message, icon, ms)


def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def load_json(path, fallback):
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                return json.load(handle)
    except Exception as exc:
        log("Could not read %s: %s" % (path, exc), xbmc.LOGWARNING)
    return fallback


def save_json(path, data):
    ensure_profile()
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, ensure_ascii=False)
    except Exception as exc:
        log("Could not write %s: %s" % (path, exc), xbmc.LOGERROR)


def setting(key, default=""):
    try:
        value = ADDON.getSetting(key)
    except Exception:
        return default
    return value if value not in (None, "") else default


def setting_bool(key, default=False):
    value = setting(key, "")
    if value == "":
        return default
    return value.lower() == "true"


def setting_int(key, default=0):
    try:
        return int(float(setting(key, str(default))))
    except (TypeError, ValueError):
        return default


def user_agent():
    who = setting("username", "").strip() or "tflanigan"
    return "FridayE621Grabber/%s (by %s on e621)" % (VERSION, who)


def get_client():
    return E621Client(
        user_agent=user_agent(),
        login=setting("username", ""),
        api_key=setting("api_key", ""),
        timeout=setting_int("timeout", 20),
        retries=setting_int("retries", 3),
        backoff=float(setting("backoff", "1.5") or 1.5),
        log=lambda m: log(m, xbmc.LOGDEBUG),
    )


def blacklist_terms():
    raw = setting("blacklist", "")
    return [t.strip().replace(" ", "_") for t in raw.replace("\n", ",").split(",") if t.strip()]


# ------------------------------------------------------------- rating switch

def active_ratings():
    """Ratings currently switched on. Seeded from settings, then user-toggleable."""
    if setting_bool("lock_safe", False):
        return ["s"]
    state = load_json(RATINGS_DB, None)
    if isinstance(state, dict) and isinstance(state.get("active"), list):
        # An intentionally empty list (the ALL OFF button) is kept as-is -
        # only a missing/corrupt file falls back to the seeded defaults below.
        return [r for r in state["active"] if r in ("s", "q", "e")]
    seeded = []
    if setting_bool("rating_safe", True):
        seeded.append("s")
    if setting_bool("rating_questionable", False):
        seeded.append("q")
    if setting_bool("rating_explicit", False):
        seeded.append("e")
    seeded = seeded or ["s"]
    save_json(RATINGS_DB, {"active": seeded})
    return seeded


def set_ratings(active):
    """Persist the switch state. An empty list is a valid, intentional state
    (the ALL OFF button) and is stored as-is, not coerced back to Safe."""
    save_json(RATINGS_DB, {"active": [r for r in ("s", "q", "e") if r in active]})


def do_rating_switch(cycle=""):
    if setting_bool("lock_safe", False):
        return notify("Rating switch is locked to Safe in settings.",
                      icon=xbmcgui.NOTIFICATION_WARNING)
    current = active_ratings()
    if cycle in ("all", "any", "*"):
        set_ratings(["s", "q", "e"])
        notify("ALL ON - nothing is filtered.", ms=5000)
        return xbmc.executebuiltin("Container.Refresh")
    if cycle in ("none", "off"):
        if setting_bool("lock_safe", False):
            return notify("Rating switch is locked to Safe in settings.",
                          icon=xbmcgui.NOTIFICATION_WARNING)
        set_ratings([])
        notify("ALL OFF - every rating is switched off, nothing will show "
               "until you pick one.", ms=6000)
        return xbmc.executebuiltin("Container.Refresh")
    if cycle == "safe":
        set_ratings(["s"])
        notify("Safe only.")
        return xbmc.executebuiltin("Container.Refresh")
    if cycle:
        # Quick toggle of a single rating from a context menu.
        current = [r for r in current if r != cycle] if cycle in current else current + [cycle]
        if not current:
            return notify("Can't switch every rating off.", icon=xbmcgui.NOTIFICATION_WARNING)
        set_ratings(current)
        return xbmc.executebuiltin("Container.Refresh")

    labels = ["%s (%s)" % (name, code.upper()) for code, name in e621_client.RATINGS]
    preselect = [i for i, (code, _n) in enumerate(e621_client.RATINGS) if code in current]
    picks = xbmcgui.Dialog().multiselect("Ratings to show", labels, preselect=preselect)
    if picks is None:
        return
    chosen = [e621_client.RATINGS[i][0] for i in picks]
    if not chosen:
        return notify("Pick at least one rating.", icon=xbmcgui.NOTIFICATION_WARNING)
    set_ratings(chosen)
    notify("Ratings: %s" % " ".join(r.upper() for r in chosen))
    xbmc.executebuiltin("Container.Refresh")


# ------------------------------------------------------------------- querying

def resolve_ratings(override=None):
    """Ratings for this view: a per-view/preset override, else the switch."""
    if setting_bool("lock_safe", False):
        return ["s"]
    if override:
        token = str(override).lower()
        if token in ("all", "any", "*", "sqe"):
            return ["s", "q", "e"]
        if token != "switch":
            picked = [r for r in ("s", "q", "e") if r in token]
            if picked:
                return picked
    return active_ratings()


def rovr_args(override):
    """Keep a rating override glued to the URLs generated inside a view."""
    return {"rovr": override} if override else {}


# ---------------------------------------------------------------- presets

def presets(enabled_only=True):
    found = []
    for slot in range(1, PRESET_SLOTS + 1):
        enabled = setting_bool("preset%s_enabled" % slot, False)
        if enabled_only and not enabled:
            continue
        tags = setting("preset%s_tags" % slot, "").strip()
        found.append({
            "slot": slot,
            "enabled": enabled,
            "name": setting("preset%s_name" % slot, "").strip() or tags or "Preset %s" % slot,
            "tags": tags,
            "ratings": setting("preset%s_ratings" % slot, "switch"),
            "limit": setting_int("preset%s_limit" % slot, 0),
        })
    return found


def preset_url(preset):
    kwargs = {"action": "browse", "tags": preset["tags"], "page": "1"}
    if preset.get("limit"):
        kwargs["limit"] = str(preset["limit"])
    if preset.get("ratings") and preset["ratings"] != "switch":
        kwargs["rovr"] = preset["ratings"]
    return url_for(**kwargs)


def apply_filters(tags, override=None):
    parts = [t for t in (tags or "").split() if t]
    has_rating = any(p.startswith(("rating:", "~rating:", "-rating:")) for p in parts)
    if not has_rating:
        fragment = e621_client.rating_query(resolve_ratings(override))
        if fragment:
            parts.extend(fragment.split())
    extra = setting("default_tags", "").strip()
    if extra:
        for token in extra.split():
            if token not in parts:
                parts.append(token)
    return " ".join(parts)


def per_page(override=None):
    if override:
        try:
            return max(1, min(int(override), 320))
        except (TypeError, ValueError):
            pass
    return max(1, min(setting_int("per_page", 60), 320))


def push_history(tags):
    tags = (tags or "").strip()
    if not tags:
        return
    hist = load_json(HISTORY_DB, [])
    hist = [h for h in hist if h != tags]
    hist.insert(0, tags)
    save_json(HISTORY_DB, hist[:40])


def download_dir():
    path = setting("download_dir", "")
    if not path:
        path = os.path.join(PROFILE, "downloads")
        if not xbmcvfs.exists(path):
            xbmcvfs.mkdirs(path)
    return path


def is_local(path):
    return "://" not in path or path.startswith("special://")


def resolve_dir(path):
    return xbmcvfs.translatePath(path) if path.startswith("special://") else path


def cached_index():
    return library.load(INDEX_DB)


def cached_downloaded_ids():
    if not setting_bool("flag_downloaded", True):
        return set()
    return library.downloaded_ids(cached_index())


# ------------------------------------------------------------------ listing UI

def add_item(label, url, is_folder=True, art=None, description="", context=None):
    item = xbmcgui.ListItem(label=label)
    art = art or {}
    icon = ADDON.getAddonInfo("icon")
    thumb = art.get("thumb", icon)
    # Transparency! (and other skins that lean on banner/clearlogo/landscape
    # tiles rather than a plain thumb) get real art instead of falling back
    # to nothing - point everything at the same source image where we don't
    # have a dedicated one.
    item.setArt({
        "thumb": thumb,
        "icon": art.get("icon", thumb),
        "poster": art.get("poster", thumb),
        "banner": art.get("banner", thumb),
        "landscape": art.get("landscape", art.get("fanart", thumb)),
        "fanart": art.get("fanart", ADDON.getAddonInfo("fanart")),
    })
    try:
        item.setInfo("pictures", {"title": label, "plot": description})
    except Exception:
        pass
    if context:
        item.addContextMenuItems(context)
    if not is_folder:
        item.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(HANDLE, url, item, is_folder)


def finish(content="files", sort=True):
    xbmcplugin.setContent(HANDLE, content)
    if sort:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def add_post_item(post, downloaded, quality, client, tags_for_context=""):
    img = e621_client.file_url(post, quality) or e621_client.file_url(post, "original")
    thumb = (post.get("preview") or {}).get("url") or img
    mark = "[COLOR FF44DD44]*[/COLOR] " if post.get("id") in downloaded else ""
    label = mark + e621_client.post_title(post)
    related = client.related_tags(post) if client else []
    context = [
        ("Rip this artist to ZIP",
         "RunPlugin(%s)" % url_for(action="rip_all", tags=e621_client.post_artists(post)[0])),
        ("Show tags", "RunPlugin(%s)" % url_for(action="show_tags", post_id=str(post.get("id")))),
        ("Search these tags", "Container.Update(%s)" % url_for(
            action="browse", tags=" ".join(related[:4]), page="1")),
        ("Rating switch", "RunPlugin(%s)" % url_for(action="ratings")),
    ]
    add_item(label, img, is_folder=False, art={"thumb": thumb, "fanart": img},
             description=", ".join(related[:40]), context=context)


def add_local_item(entry, index_pos=0):
    label = "[COLOR FF44DD44]*[/COLOR] %s%s" % (
        ("#%s " % entry["id"]) if entry.get("id") else "",
        entry.get("artist", "unknown"))
    if entry.get("source"):
        label += "  (%s)" % entry["source"]
    context = []
    if entry.get("id"):
        context.append(("Show tags", "RunPlugin(%s)" % url_for(
            action="show_tags", post_id=str(entry["id"]))))
    add_item(label, entry["path"], is_folder=False,
             art={"thumb": entry["path"], "fanart": entry["path"]},
             description=entry.get("path", ""), context=context)


# ---------------------------------------------------------------------- routes

def root():
    add_item("[B]Search tags[/B]  (space separated, - to exclude)", url_for(action="search"),
             description="Classic multi-tag search. Example: wolf forest -comic order:score")
    add_item("[B]Fuzzy tag search[/B]  (find tags, then pick)", url_for(action="fuzzy"),
             description="Type a partial tag, get real matching tags with post counts.")
    add_item("[B]Multi-tag builder[/B]", url_for(action="builder"))
    add_item("[B]Rating switch:[/B] %s" % e621_client.rating_label(active_ratings()),
             url_for(action="ratings"), is_folder=False,
             description="Toggle Safe / Questionable / Explicit for every search and rip.")
    add_item("[B][COLOR FF44DD44]ALL RATINGS ON[/COLOR][/B]  (S+Q+E, no filter at all)",
             url_for(action="ratings", toggle="all"), is_folder=False,
             description="Drops every rating restriction from searches, viewer and rips.")
    add_item("[B][COLOR FFFF5555]ALL RATINGS OFF[/COLOR][/B]  (switch every rating off)",
             url_for(action="ratings", toggle="off"), is_folder=False,
             description="Switches Safe, Questionable and Explicit all off - browsing "
                         "shows nothing until you pick at least one again.")
    live = presets()
    if live:
        add_item("[B]Presets[/B]  (%s on)" % len(live), url_for(action="presets"),
                 description="Your saved one-tap searches. Turn them on/off in Settings > Presets.")
    else:
        add_item("Presets  (none enabled - Settings > Presets)", url_for(action="presets"))
    add_item("[B]Viewer - ALL pics (downloaded or not)[/B]", url_for(action="library"),
             description="Your downloaded archive, plus live e621 results, in one place.")
    add_item("Hot right now", url_for(action="browse", tags="order:rank", page="1"))
    add_item("Top scored this week", url_for(action="browse", tags="order:score date:week", page="1"))
    add_item("Newest uploads", url_for(action="browse", tags="", page="1"))
    add_item("Saved searches", url_for(action="saved"))
    add_item("Search history", url_for(action="history"))
    add_item("Open settings", url_for(action="settings"), is_folder=False)
    finish()


def do_search():
    query = xbmcgui.Dialog().input("Tags (space separated, - excludes)",
                                   type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        return finish()
    push_history(query)
    xbmc.executebuiltin("Container.Update(%s)" % url_for(action="browse", tags=query, page="1"))


def do_fuzzy():
    dialog = xbmcgui.Dialog()
    term = dialog.input("Partial tag to look up", type=xbmcgui.INPUT_ALPHANUM)
    if not term:
        return finish()
    try:
        matches = get_client().tag_suggest(term, limit=setting_int("suggest_limit", 40))
    except E621Error as exc:
        notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR)
        return finish()
    if not matches:
        notify("No tags matched '%s'" % term, icon=xbmcgui.NOTIFICATION_WARNING)
        return finish()
    labels = ["[COLOR %s]%s[/COLOR]  (%s posts)" % (
        CAT_COLOURS.get(t["category"], "FFFFFFFF"), t["name"], t["count"]) for t in matches]
    picks = dialog.multiselect("Pick tags for the search", labels)
    if not picks:
        return finish()
    query = " ".join(matches[i]["name"] for i in picks)
    push_history(query)
    xbmc.executebuiltin("Container.Update(%s)" % url_for(action="browse", tags=query, page="1"))


# ----------------------------------------------------------- multi-tag builder

def builder_query(state):
    parts = list(state.get("include", []))
    parts += ["-%s" % t for t in state.get("exclude", [])]
    return " ".join(parts)


def do_builder():
    state = load_json(BUILDER_DB, {"include": [], "exclude": []})
    query = builder_query(state)
    add_item("[B]Current query:[/B] %s" % (query or "(empty)"), url_for(action="noop"), is_folder=False)
    add_item("+ Add include tag (fuzzy pick)", url_for(action="builder_add", kind="include"), is_folder=False)
    add_item("- Add exclude tag (fuzzy pick)", url_for(action="builder_add", kind="exclude"), is_folder=False)
    add_item("+ Type a tag manually", url_for(action="builder_add", kind="manual"), is_folder=False)
    if query:
        add_item("[B]>> Browse this query[/B]", url_for(action="browse", tags=query, page="1"))
        add_item(">> View ALL pics for this query", url_for(action="allpics", tags=query))
        add_item(">> Rip ALL pages of this query to ZIP",
                 url_for(action="rip_all", tags=query), is_folder=False)
        add_item(">> Save this query", url_for(action="save_search", tags=query), is_folder=False)
    for tag in state.get("include", []):
        add_item("include: %s" % tag, url_for(action="builder_del", kind="include", tag=tag), is_folder=False)
    for tag in state.get("exclude", []):
        add_item("exclude: %s" % tag, url_for(action="builder_del", kind="exclude", tag=tag), is_folder=False)
    if query:
        add_item("[COLOR FFFF5555]Clear builder[/COLOR]", url_for(action="builder_clear"), is_folder=False)
    finish()


def do_builder_add(kind):
    state = load_json(BUILDER_DB, {"include": [], "exclude": []})
    dialog = xbmcgui.Dialog()
    if kind == "manual":
        raw = dialog.input("Tag to add", type=xbmcgui.INPUT_ALPHANUM)
        if not raw:
            return
        bucket = "exclude" if raw.startswith("-") else "include"
        state.setdefault(bucket, []).append(raw.lstrip("-").replace(" ", "_"))
        state[bucket] = list(dict.fromkeys(state[bucket]))
        save_json(BUILDER_DB, state)
        return xbmc.executebuiltin("Container.Refresh")

    term = dialog.input("Partial tag to look up", type=xbmcgui.INPUT_ALPHANUM)
    if not term:
        return
    try:
        matches = get_client().tag_suggest(term, limit=setting_int("suggest_limit", 40))
    except E621Error as exc:
        return notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR)
    if not matches:
        return notify("No tags matched '%s'" % term, icon=xbmcgui.NOTIFICATION_WARNING)
    labels = ["%s  (%s posts)" % (t["name"], t["count"]) for t in matches]
    picks = dialog.multiselect("Add to %s" % kind, labels)
    if not picks:
        return
    state.setdefault(kind, []).extend(matches[i]["name"] for i in picks)
    state[kind] = list(dict.fromkeys(state[kind]))
    save_json(BUILDER_DB, state)
    xbmc.executebuiltin("Container.Refresh")


def do_builder_del(kind, tag):
    state = load_json(BUILDER_DB, {"include": [], "exclude": []})
    state[kind] = [t for t in state.get(kind, []) if t != tag]
    save_json(BUILDER_DB, state)
    xbmc.executebuiltin("Container.Refresh")


def do_builder_clear():
    save_json(BUILDER_DB, {"include": [], "exclude": []})
    xbmc.executebuiltin("Container.Refresh")


# ------------------------------------------------------------------ pagination

def page_number(page):
    try:
        return int(page)
    except (TypeError, ValueError):
        return 1


def do_jump_page(tags, page, limit, rovr=""):
    current = page_number(page)
    value = xbmcgui.Dialog().numeric(0, "Jump to page", str(current))
    if not value:
        return
    target = max(1, int(value))
    xbmc.executebuiltin("Container.Update(%s)" % url_for(
        action="browse", tags=tags, page=str(target), limit=str(limit), **rovr_args(rovr)))


def do_page_size(tags, page, limit, rovr=""):
    dialog = xbmcgui.Dialog()
    labels = ["%s per page" % n for n in PAGE_SIZE_CHOICES] + ["Custom number..."]
    choice = dialog.select("Posts per page (current: %s)" % limit, labels)
    if choice < 0:
        return
    if choice == len(PAGE_SIZE_CHOICES):
        value = dialog.numeric(0, "Posts per page (1-320)", str(limit))
        if not value:
            return
        new_limit = max(1, min(int(value), 320))
    else:
        new_limit = PAGE_SIZE_CHOICES[choice]
    if setting_bool("ask_save_page_size", True) and dialog.yesno(
            ADDON_NAME, "Use %s per page everywhere from now on?" % new_limit,
            yeslabel="Save as default", nolabel="Just this view"):
        ADDON.setSetting("per_page", str(new_limit))
    xbmc.executebuiltin("Container.Update(%s)" % url_for(
        action="browse", tags=tags, page="1", limit=str(new_limit), **rovr_args(rovr)))


def add_pagination_controls(tags, page, limit, count, total, rovr=""):
    current = page_number(page)
    rv = rovr_args(rovr)
    total_pages = math.ceil(total / float(limit)) if total else 0
    header = "Page %s%s  -  %s per page" % (
        current, ("/%s" % total_pages) if total_pages else "", limit)
    add_item("[B]%s[/B]%s" % (header, ("   (%s posts found)" % total) if total else ""),
             url_for(action="noop"), is_folder=False)
    add_item("Jump to page...", url_for(action="jump_page", tags=tags, page=str(current),
                                        limit=str(limit), **rv), is_folder=False)
    add_item("Change page size (currently %s)" % limit,
             url_for(action="page_size", tags=tags, page=str(current), limit=str(limit), **rv),
             is_folder=False)
    if current > 1:
        add_item("<< Previous page (%s)" % (current - 1),
                 url_for(action="browse", tags=tags, page=str(current - 1), limit=str(limit), **rv))
        add_item("<< First page", url_for(action="browse", tags=tags, page="1", limit=str(limit), **rv))


def do_browse(tags, page, limit_arg, rovr=""):
    if not resolve_ratings(rovr):
        add_item("[COLOR FFFF5555]No ratings selected[/COLOR] - open the Rating "
                 "switch and pick S/Q/E, or tap ALL RATINGS ON.",
                 url_for(action="ratings"), is_folder=False)
        return finish("images")
    client = get_client()
    query = apply_filters(tags, rovr)
    limit = per_page(limit_arg)
    rv = rovr_args(rovr)
    try:
        posts = client.posts(tags=query, limit=limit, page=page)
    except E621Error as exc:
        notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR, ms=6000)
        return finish("images")

    black = blacklist_terms()
    posts = [p for p in posts if not e621_client.is_blacklisted(p, black)]
    total = client.count(query) if setting_bool("show_totals", True) else 0
    downloaded = cached_downloaded_ids()
    ratings_here = resolve_ratings(rovr)

    add_pagination_controls(tags, page, limit, len(posts), total, rovr)
    add_item("[B]Rating switch:[/B] %s%s" % (
        e621_client.rating_label(ratings_here),
        "  [COLOR FFAAAAAA](this view)[/COLOR]" if rovr else ""),
             url_for(action="ratings"), is_folder=False)
    if len(ratings_here) < 3:
        add_item("[COLOR FFFFAA00]ALL RATINGS for this view[/COLOR]",
                 url_for(action="browse", tags=tags, page="1", limit=str(limit), rovr="all"))
    add_item("[B][COLOR FF44DD44]Rip THIS page to ZIP[/COLOR][/B]  (%s posts)" % len(posts),
             url_for(action="rip_page", tags=tags, page=str(page), limit=str(limit), **rv),
             is_folder=False)
    add_item("[B][COLOR FFFFAA00]Rip ALL pages of this search to ZIP[/COLOR][/B]",
             url_for(action="rip_all", tags=tags, limit=str(limit), **rv), is_folder=False)
    add_item("View ALL pics for this search (local + remote)",
             url_for(action="allpics", tags=tags, limit=str(limit), **rv))
    add_item("Save this search", url_for(action="save_search", tags=tags), is_folder=False)
    add_item("Save as preset", url_for(action="preset_save", tags=tags, limit=str(limit),
                                       rovr=rovr or "switch"), is_folder=False)

    quality = setting("view_quality", "sample")
    for post in posts:
        add_post_item(post, downloaded, quality, client, tags)

    if len(posts) >= limit:
        nxt = page_number(page) + 1
        add_item("[B]Next page >>[/B] (page %s)" % nxt,
                 url_for(action="browse", tags=tags, page=str(nxt), limit=str(limit), **rv))
    if not posts:
        add_item("No results for '%s'" % (tags or "newest"), url_for(action="noop"), is_folder=False)

    xbmcplugin.setPluginCategory(HANDLE, "%s - page %s" % (tags or "newest", page))
    finish("images")


# ------------------------------------------------------------------- presets

def do_presets():
    live = presets()
    if not live:
        add_item("No presets enabled yet.", url_for(action="noop"), is_folder=False)
        add_item("[B]Open Settings > Presets[/B] to switch some on",
                 url_for(action="settings"), is_folder=False)
        add_item("Presets are off by default - flip 'enabled', type a name and tags.",
                 url_for(action="noop"), is_folder=False)
        return finish()
    for preset in live:
        label = "[B]%s[/B]" % preset["name"]
        detail = preset["tags"] or "newest"
        if preset["ratings"] != "switch":
            detail += "   [%s]" % (" ".join(r.upper() for r in resolve_ratings(preset["ratings"])))
        if preset["limit"]:
            detail += "   (%s/page)" % preset["limit"]
        context = [
            ("View ALL pics", "Container.Update(%s)" % url_for(
                action="allpics", tags=preset["tags"],
                **rovr_args(preset["ratings"] if preset["ratings"] != "switch" else ""))),
            ("Rip ALL pages to ZIP", "RunPlugin(%s)" % url_for(
                action="rip_all", tags=preset["tags"],
                **rovr_args(preset["ratings"] if preset["ratings"] != "switch" else ""))),
            ("Turn this preset off", "RunPlugin(%s)" % url_for(
                action="preset_toggle", slot=str(preset["slot"]))),
        ]
        add_item("%s  -  %s" % (label, detail), preset_url(preset),
                 description=preset["tags"], context=context)
    add_item("Edit presets in Settings", url_for(action="settings"), is_folder=False)
    finish()


def do_preset_save(tags, limit, rovr):
    dialog = xbmcgui.Dialog()
    slots = presets(enabled_only=False)
    labels = []
    for preset in slots:
        state = "ON " if preset["enabled"] else "off"
        labels.append("Slot %s [%s]  %s" % (preset["slot"], state,
                                            preset["tags"] or "(empty)"))
    choice = dialog.select("Save into which preset slot?", labels)
    if choice < 0:
        return
    slot = slots[choice]["slot"]
    name = dialog.input("Preset name", defaultt=tags or "newest", type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        return
    ADDON.setSetting("preset%s_name" % slot, name)
    ADDON.setSetting("preset%s_tags" % slot, tags or "")
    ADDON.setSetting("preset%s_ratings" % slot, rovr or "switch")
    ADDON.setSetting("preset%s_limit" % slot, str(limit or 0))
    ADDON.setSetting("preset%s_enabled" % slot, "true")
    notify("Preset %s saved and switched on: %s" % (slot, name), ms=5000)


def do_preset_toggle(slot):
    key = "preset%s_enabled" % slot
    now = setting_bool(key, False)
    ADDON.setSetting(key, "false" if now else "true")
    notify("Preset %s %s" % (slot, "off" if now else "on"))
    xbmc.executebuiltin("Container.Refresh")


# ---------------------------------------------------------- viewer / library

def do_library():
    index = cached_index()
    entries = index.get("entries", [])
    add_item("[B]All downloaded pics[/B]  (%s on disk)" % len(entries), url_for(action="lib_all"))
    add_item("By artist  (%s artists)" % len(library.by_artist(index)), url_for(action="lib_artists"))
    add_item("By ZIP archive  (%s archives)" % index.get("archives", 0), url_for(action="lib_archives"))
    add_item("[B]Everything for a search[/B] - local + live e621", url_for(action="allpics_prompt"), is_folder=False)
    add_item("Slideshow of everything downloaded",
             url_for(action="slideshow", target=url_for(action="lib_all")), is_folder=False)
    add_item("[COLOR FFFFAA00]Rebuild index[/COLOR]  (run after new rips)",
             url_for(action="lib_rebuild"), is_folder=False)
    add_item("Scanning: %s" % (index.get("root") or download_dir()), url_for(action="noop"), is_folder=False)
    finish()


def do_lib_all(artist=None, archive=None):
    index = cached_index()
    entries = index.get("entries", [])
    if artist:
        entries = [e for e in entries if e.get("artist") == artist]
    if archive:
        entries = [e for e in entries if (e.get("source") or "Loose files") == archive]
    if not entries:
        add_item("Nothing indexed yet - rip something, then rebuild the index.",
                 url_for(action="lib_rebuild"), is_folder=False)
    for entry in entries:
        add_local_item(entry)
    xbmcplugin.setPluginCategory(HANDLE, artist or archive or "All downloaded pics")
    finish("images")


def do_lib_artists():
    for artist, entries in sorted(library.by_artist(cached_index()).items()):
        add_item("%s  (%s)" % (artist, len(entries)),
                 url_for(action="lib_all", artist=artist),
                 art={"thumb": entries[0]["path"]})
    finish()


def do_lib_archives():
    for name, entries in sorted(library.by_archive(cached_index()).items()):
        add_item("%s  (%s)" % (name, len(entries)),
                 url_for(action="lib_all", archive=name),
                 art={"thumb": entries[0]["path"]})
    finish()


def do_lib_rebuild():
    root = download_dir()
    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, "Indexing %s" % root)

    def progress(done, total, text):
        if dialog.iscanceled():
            return False
        dialog.update(int(done * 100 / total) if total else 0, "Reading archives\n%s" % text)
        return True

    try:
        index = library.scan(root, progress=progress, log=lambda m: log(m, xbmc.LOGWARNING))
    except Exception as exc:
        dialog.close()
        return notify("Index failed: %s" % exc, icon=xbmcgui.NOTIFICATION_ERROR, ms=7000)
    dialog.close()
    library.save(INDEX_DB, index)
    notify("Indexed %s pics from %s archives" % (len(index["entries"]), index["archives"]), ms=6000)
    xbmc.executebuiltin("Container.Refresh")


def do_allpics_prompt():
    query = xbmcgui.Dialog().input("Tags for the combined view (blank = newest)",
                                   type=xbmcgui.INPUT_ALPHANUM)
    if query is None:
        return
    xbmc.executebuiltin("Container.Update(%s)" % url_for(action="allpics", tags=query))


def do_allpics(tags, limit_arg, rovr=""):
    """One flat directory holding every matching pic: local copies first, then
    everything e621 has that isn't on disk yet. Slideshow-ready."""
    if not resolve_ratings(rovr):
        add_item("[COLOR FFFF5555]No ratings selected[/COLOR] - open the Rating "
                 "switch and pick S/Q/E, or tap ALL RATINGS ON.",
                 url_for(action="ratings"), is_folder=False)
        return finish("images")
    limit = per_page(limit_arg)
    pages = max(1, setting_int("viewer_pages", 5))
    client = get_client()
    query = apply_filters(tags, rovr)
    black = blacklist_terms()
    index = cached_index()
    local = index.get("entries", [])
    local_ids = library.downloaded_ids(index)

    wanted_tags = set(t.lower() for t in (tags or "").split() if not t.startswith("-"))
    matched_local = local
    if wanted_tags and setting_bool("viewer_filter_local", True):
        matched_local = [e for e in local
                         if e.get("artist", "").lower() in wanted_tags] or local

    remote = []
    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, "Gathering pics...")
    try:
        for page_no, posts in client.iter_pages(tags=query, limit=limit, max_pages=pages):
            if dialog.iscanceled():
                break
            dialog.update(int(page_no * 100 / pages), "Page %s of %s\n%s remote posts so far"
                          % (page_no, pages, len(remote)))
            remote.extend(p for p in posts if not e621_client.is_blacklisted(p, black))
    except E621Error as exc:
        notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR, ms=6000)
    finally:
        dialog.close()

    add_item("[B]%s local + %s from e621[/B]  -  %s" % (
        len(matched_local), len(remote), tags or "newest"), url_for(action="noop"), is_folder=False)
    add_item("Start slideshow of this view",
             url_for(action="slideshow", target=url_for(action="allpics", tags=tags,
                                                        limit=str(limit))), is_folder=False)
    add_item("Load more pages (currently %s)" % pages, url_for(action="viewer_pages"), is_folder=False)
    add_item("[B]Rating switch:[/B] %s" % e621_client.rating_label(resolve_ratings(rovr)),
             url_for(action="ratings"), is_folder=False)
    if len(resolve_ratings(rovr)) < 3:
        add_item("[COLOR FFFFAA00]ALL RATINGS for this view[/COLOR]",
                 url_for(action="allpics", tags=tags, limit=str(limit), rovr="all"))

    if setting_bool("viewer_local_first", True):
        for entry in matched_local:
            add_local_item(entry)

    quality = setting("view_quality", "sample")
    for post in remote:
        if post.get("id") in local_ids and setting_bool("viewer_local_first", True):
            continue
        add_post_item(post, local_ids, quality, client, tags)

    if not setting_bool("viewer_local_first", True):
        for entry in matched_local:
            add_local_item(entry)

    xbmcplugin.setPluginCategory(HANDLE, "All pics - %s" % (tags or "newest"))
    finish("images")


def do_viewer_pages():
    current = setting_int("viewer_pages", 5)
    value = xbmcgui.Dialog().numeric(0, "Pages to pull into the viewer", str(current))
    if not value:
        return
    ADDON.setSetting("viewer_pages", str(max(1, int(value))))
    xbmc.executebuiltin("Container.Refresh")


def do_slideshow(target):
    if not target:
        return
    recursive = ",recursive" if setting_bool("slideshow_recursive", False) else ""
    xbmc.executebuiltin('SlideShow(%s%s)' % (target, recursive))


def do_show_tags(post_id):
    try:
        posts = get_client().posts(tags="id:%s" % post_id, limit=1)
    except E621Error as exc:
        return notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR)
    if not posts:
        return notify("Post not found")
    groups = posts[0].get("tags") or {}
    lines = []
    for key in ("artist", "character", "copyright", "species", "general", "meta"):
        values = groups.get(key) or []
        if values:
            lines.append("[B]%s[/B]\n%s\n" % (key.title(), ", ".join(values)))
    lines.append("[B]Rating[/B]\n%s" % (posts[0].get("rating") or "?").upper())
    xbmcgui.Dialog().textviewer("Post #%s" % post_id, "\n".join(lines) or "No tags.")


# ------------------------------------------------------------------- ripping

def _zip_destination(base_name):
    folder = download_dir()
    filename = ripper.zip_stamp(base_name)
    if is_local(folder):
        return os.path.join(resolve_dir(folder), filename), None
    tmp = os.path.join(xbmcvfs.translatePath("special://temp"), filename)
    return tmp, folder.rstrip("/") + "/" + filename


def _make_ripper():
    return ripper.Ripper(
        user_agent=user_agent(),
        quality=setting("download_quality", "original"),
        threads=setting_int("threads", 4),
        timeout=setting_int("timeout", 20) + 10,
        retries=setting_int("retries", 3),
        write_manifest=setting_bool("write_manifest", True),
        compress=setting_bool("compress_zip", False),
        log=lambda m: log(m, xbmc.LOGWARNING),
    )


def _run_rip(batches, base_name, total_hint, label):
    zip_path, remote = _zip_destination(base_name)
    folder = os.path.dirname(zip_path)
    if folder and not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, "Starting rip...")

    def progress(done, total, text):
        if dialog.iscanceled():
            return False
        dialog.update(min(int(done * 100 / total) if total else 0, 100), text)
        return True

    rip = _make_ripper()
    try:
        result = rip.rip(batches, zip_path, progress=progress, total_hint=total_hint, label=label)
    except Exception as exc:
        dialog.close()
        log("Rip failed: %s" % exc, xbmc.LOGERROR)
        return notify("Rip failed: %s" % exc, icon=xbmcgui.NOTIFICATION_ERROR, ms=7000)
    dialog.close()

    if remote:
        if xbmcvfs.copy(zip_path, remote):
            xbmcvfs.delete(zip_path)
            zip_path = remote
        else:
            notify("Could not copy to %s - left in special://temp" % remote,
                   icon=xbmcgui.NOTIFICATION_WARNING, ms=7000)

    if result["saved"]:
        notify("ZIP done: %s saved, %s failed%s" % (
            result["saved"], result["failed"],
            " (cancelled)" if result["cancelled"] else ""), ms=7000)
        log("Wrote %s" % zip_path)
        if setting_bool("auto_index", True):
            index = library.scan(download_dir(), log=lambda m: log(m, xbmc.LOGWARNING))
            library.save(INDEX_DB, index)
    else:
        notify("Nothing downloaded - check tags, rating switch or login.",
               icon=xbmcgui.NOTIFICATION_WARNING, ms=6000)


def do_rip_page(tags, page, limit_arg, rovr=""):
    if not resolve_ratings(rovr):
        return notify("No ratings selected - pick S/Q/E or ALL RATINGS ON first.",
                      icon=xbmcgui.NOTIFICATION_WARNING, ms=6000)
    client = get_client()
    query = apply_filters(tags, rovr)
    limit = per_page(limit_arg)
    try:
        posts = client.posts(tags=query, limit=limit, page=page)
    except E621Error as exc:
        return notify(str(exc), icon=xbmcgui.NOTIFICATION_ERROR)
    posts = [p for p in posts if not e621_client.is_blacklisted(p, blacklist_terms())]
    if not posts:
        return notify("Nothing on this page to rip.", icon=xbmcgui.NOTIFICATION_WARNING)
    if setting_bool("skip_existing", True):
        have = cached_downloaded_ids()
        posts = [p for p in posts if p.get("id") not in have] or posts
    if setting_bool("confirm_rips", True):
        if not xbmcgui.Dialog().yesno(
                ADDON_NAME, "Rip %s posts from page %s?\nRatings: %s" % (
                    len(posts), page, " ".join(r.upper() for r in resolve_ratings(rovr)))):
            return
    _run_rip([posts], "%s_p%s" % (tags or "newest", page), len(posts),
             "Page %s - %s" % (page, tags or "newest"))


def do_rip_all(tags, limit_arg, rovr=""):
    if not resolve_ratings(rovr):
        return notify("No ratings selected - pick S/Q/E or ALL RATINGS ON first.",
                      icon=xbmcgui.NOTIFICATION_WARNING, ms=6000)
    client = get_client()
    query = apply_filters(tags, rovr)
    black = blacklist_terms()
    limit = per_page(limit_arg)
    max_pages = setting_int("max_pages", 10)

    total = client.count(query)
    capped = total if not max_pages else min(total, max_pages * limit)
    if setting_bool("confirm_rips", True):
        msg = "Search: %s\nRatings: %s\nPosts found: %s\nWill grab up to: %s (max %s pages x %s)" % (
            tags or "newest", " ".join(r.upper() for r in resolve_ratings(rovr)),
            total or "?", capped or "?", max_pages or "unlimited", limit)
        if not xbmcgui.Dialog().yesno(ADDON_NAME, msg, yeslabel="Rip it", nolabel="Nope"):
            return

    def batches():
        for _page_no, posts in client.iter_pages(tags=query, limit=limit, max_pages=max_pages):
            yield [p for p in posts if not e621_client.is_blacklisted(p, black)]

    _run_rip(batches(), tags or "newest", capped, "Full rip - %s" % (tags or "newest"))


# ------------------------------------------------------- saved searches / misc

def do_saved():
    saved = load_json(SEARCH_DB, [])
    if not saved:
        add_item("(nothing saved yet)", url_for(action="noop"), is_folder=False)
    for entry in saved:
        tags = entry.get("tags", "")
        context = [
            ("Rip ALL pages to ZIP", "RunPlugin(%s)" % url_for(action="rip_all", tags=tags)),
            ("View ALL pics", "Container.Update(%s)" % url_for(action="allpics", tags=tags)),
            ("Delete", "RunPlugin(%s)" % url_for(action="del_search", tags=tags)),
        ]
        add_item(entry.get("name", tags), url_for(action="browse", tags=tags, page="1"),
                 description=tags, context=context)
    finish()


def do_save_search(tags):
    name = xbmcgui.Dialog().input("Name this search", defaultt=tags or "newest",
                                  type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        return
    saved = [s for s in load_json(SEARCH_DB, []) if s.get("tags") != tags]
    saved.insert(0, {"name": name, "tags": tags})
    save_json(SEARCH_DB, saved)
    notify("Saved: %s" % name)


def do_del_search(tags):
    save_json(SEARCH_DB, [s for s in load_json(SEARCH_DB, []) if s.get("tags") != tags])
    xbmc.executebuiltin("Container.Refresh")


def do_history():
    hist = load_json(HISTORY_DB, [])
    if not hist:
        add_item("(no history yet)", url_for(action="noop"), is_folder=False)
    for tags in hist:
        context = [
            ("Rip ALL pages to ZIP", "RunPlugin(%s)" % url_for(action="rip_all", tags=tags)),
            ("View ALL pics", "Container.Update(%s)" % url_for(action="allpics", tags=tags)),
        ]
        add_item(tags, url_for(action="browse", tags=tags, page="1"), context=context)
    if hist:
        add_item("[COLOR FFFF5555]Clear history[/COLOR]", url_for(action="clear_history"), is_folder=False)
    finish()


def do_clear_history():
    save_json(HISTORY_DB, [])
    xbmc.executebuiltin("Container.Refresh")


# ----------------------------------------------------------------------- entry

ROUTES = {
    "root": lambda a: root(),
    "search": lambda a: do_search(),
    "fuzzy": lambda a: do_fuzzy(),
    "browse": lambda a: do_browse(a.get("tags", ""), a.get("page", "1"), a.get("limit"),
                                  a.get("rovr", "")),
    "jump_page": lambda a: do_jump_page(a.get("tags", ""), a.get("page", "1"),
                                        per_page(a.get("limit")), a.get("rovr", "")),
    "page_size": lambda a: do_page_size(a.get("tags", ""), a.get("page", "1"),
                                        per_page(a.get("limit")), a.get("rovr", "")),
    "presets": lambda a: do_presets(),
    "preset_save": lambda a: do_preset_save(a.get("tags", ""), a.get("limit"), a.get("rovr", "switch")),
    "preset_toggle": lambda a: do_preset_toggle(a.get("slot", "1")),
    "ratings": lambda a: do_rating_switch(a.get("toggle", "")),
    "builder": lambda a: do_builder(),
    "builder_add": lambda a: do_builder_add(a.get("kind", "include")),
    "builder_del": lambda a: do_builder_del(a.get("kind", "include"), a.get("tag", "")),
    "builder_clear": lambda a: do_builder_clear(),
    "library": lambda a: do_library(),
    "lib_all": lambda a: do_lib_all(a.get("artist"), a.get("archive")),
    "lib_artists": lambda a: do_lib_artists(),
    "lib_archives": lambda a: do_lib_archives(),
    "lib_rebuild": lambda a: do_lib_rebuild(),
    "allpics": lambda a: do_allpics(a.get("tags", ""), a.get("limit"), a.get("rovr", "")),
    "allpics_prompt": lambda a: do_allpics_prompt(),
    "viewer_pages": lambda a: do_viewer_pages(),
    "slideshow": lambda a: do_slideshow(a.get("target", "")),
    "rip_page": lambda a: do_rip_page(a.get("tags", ""), a.get("page", "1"), a.get("limit"),
                                      a.get("rovr", "")),
    "rip_all": lambda a: do_rip_all(a.get("tags", ""), a.get("limit"), a.get("rovr", "")),
    "show_tags": lambda a: do_show_tags(a.get("post_id", "")),
    "saved": lambda a: do_saved(),
    "save_search": lambda a: do_save_search(a.get("tags", "")),
    "del_search": lambda a: do_del_search(a.get("tags", "")),
    "history": lambda a: do_history(),
    "clear_history": lambda a: do_clear_history(),
    "settings": lambda a: ADDON.openSettings(),
    "noop": lambda a: None,
}


def router():
    ensure_profile()
    handler = ROUTES.get(ARGS.get("action", "root"), ROUTES["root"])
    handler(ARGS)


if __name__ == "__main__":
    try:
        router()
    except Exception as exc:  # last-ditch so Kodi never shows a raw traceback
        log("Unhandled error: %s" % exc, xbmc.LOGERROR)
        notify("Error: %s" % exc, icon=xbmcgui.NOTIFICATION_ERROR, ms=7000)
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
