# Angel — lightweight Kodi internet radio addon
import sys
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])

STATIONS = [
    ("SomaFM — Drone Zone", "https://somafm.com/dronezone256.pls"),
    ("SomaFM — Groove Salad", "https://somafm.com/groovesalad256.pls"),
    ("SomaFM — Space Station Soma", "https://somafm.com/spacestation256.pls"),
]

def add_folder(label, url):
    item = xbmcgui.ListItem(label=f"✦ {label}")
    item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, url, item, False)

def main():
    if len(sys.argv) < 3 or sys.argv[2] in ("", "?"):
        xbmcplugin.setPluginCategory(HANDLE, "ANGEL")
        for label, url in STATIONS:
            add_folder(label, url)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    url = sys.argv[2]
    item = xbmcgui.ListItem(path=url)
    item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, item)

if __name__ == "__main__":
    main()
