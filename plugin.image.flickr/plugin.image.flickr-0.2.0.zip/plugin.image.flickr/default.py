# -*- coding: utf-8 -*-
import sys, json, urllib.parse, urllib.request, urllib.error
import time, random, hmac, hashlib, base64, webbrowser
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
API = "https://api.flickr.com/services/rest"
OAUTH_REQUEST = "https://www.flickr.com/services/oauth/request_token"
OAUTH_AUTHORIZE = "https://www.flickr.com/services/oauth/authorize"
OAUTH_ACCESS = "https://www.flickr.com/services/oauth/access_token"

def notify(msg, error=False):
    xbmcgui.Dialog().notification("Flickr", msg,
        xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 4000)

def esc(s):
    return urllib.parse.quote(str(s), safe="~-._")

def oauth_header(method, url, params, consumer_secret, token_secret=""):
    oauth = {
        "oauth_consumer_key": ADDON.getSetting("api_key").strip(),
        "oauth_nonce": "%x" % random.getrandbits(64),
        "oauth_signature_method": "HMAC-SHA1",
        "oauth_timestamp": str(int(time.time())),
        "oauth_version": "1.0",
    }
    oauth.update(params)
    items = sorted((esc(k), esc(v)) for k, v in oauth.items())
    normalized = "&".join("%s=%s" % x for x in items)
    base = "&".join([method.upper(), esc(url), esc(normalized)])
    key = esc(consumer_secret) + "&" + esc(token_secret)
    sig = base64.b64encode(hmac.new(key.encode(), base.encode(), hashlib.sha1).digest()).decode()
    oauth["oauth_signature"] = sig
    header = "OAuth " + ", ".join('%s="%s"' % (esc(k), esc(v))
                                  for k, v in oauth.items()
                                  if k.startswith("oauth_"))
    return header

def oauth_post(url, params, token_secret=""):
    consumer_secret = ADDON.getSetting("api_secret").strip()
    header = oauth_header("POST", url, params, consumer_secret, token_secret)
    data = urllib.parse.urlencode(params).encode()
    req = urllib.request.Request(url, data=data, headers={
        "Authorization": header,
        "User-Agent": "Kodi-Flickr/0.2.0"
    })
    with urllib.request.urlopen(req, timeout=20) as r:
        return urllib.parse.parse_qs(r.read().decode())

def get_saved(name):
    return ADDON.getSetting(name).strip()

def set_saved(name, value):
    ADDON.setSetting(name, value)

def logged_in():
    return bool(get_saved("oauth_token") and get_saved("oauth_token_secret"))

def authenticate():
    if not ADDON.getSetting("api_key").strip() or not ADDON.getSetting("api_secret").strip():
        notify("Enter Flickr API key and secret in Settings", True)
        return False
    try:
        result = oauth_post(OAUTH_REQUEST, {"oauth_callback": "oob"})
        token = result["oauth_token"][0]
        secret = result["oauth_token_secret"][0]
        url = OAUTH_AUTHORIZE + "?" + urllib.parse.urlencode({
            "oauth_token": token, "perms": "read"
        })
        xbmcgui.Dialog().ok(
            "Flickr sign-in",
            "Open this URL in a browser and authorize the Kodi Flickr addon:\n\n" + url
        )
        try:
            webbrowser.open(url)
        except Exception:
            pass
        verifier = xbmcgui.Dialog().input("Enter Flickr authorization code",
                                          type=xbmcgui.INPUT_ALPHANUM)
        if not verifier:
            return False
        result = oauth_post(OAUTH_ACCESS, {
            "oauth_token": token,
            "oauth_verifier": verifier
        }, secret)
        set_saved("oauth_token", result["oauth_token"][0])
        set_saved("oauth_token_secret", result["oauth_token_secret"][0])
        set_saved("user_nsid", result.get("user_nsid", [""])[0])
        set_saved("username", result.get("username", [""])[0])
        notify("Flickr account connected")
        return True
    except Exception as e:
        xbmc.log("Flickr OAuth error: %s" % e, xbmc.LOGERROR)
        notify("Flickr sign-in failed", True)
        return False

def api_call(method, **params):
    params.update({"method": method, "api_key": ADDON.getSetting("api_key").strip(),
                   "format": "json", "nojsoncallback": "1"})
    token = get_saved("oauth_token")
    secret = get_saved("oauth_token_secret")
    if token:
        params["oauth_token"] = token
        header = oauth_header("GET", API, params,
                              ADDON.getSetting("api_secret").strip(), secret)
    else:
        header = None
    url = API + "?" + urllib.parse.urlencode(params)
    headers = {"User-Agent": "Kodi-Flickr/0.2.0"}
    if header:
        headers["Authorization"] = header
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        xbmc.log("Flickr API error: %s" % e, xbmc.LOGERROR)
        notify("Flickr API request failed", True)
        return None

def make_url(route, **params):
    q = {"route": route}; q.update(params)
    return sys.argv[0] + "?" + urllib.parse.urlencode(q)

def add_folder(label, route):
    li = xbmcgui.ListItem(label)
    li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, make_url(route), li, True)

def add_photo(p):
    title = p.get("title", "Untitled")
    owner = p.get("ownername", "")
    image = p.get("url_l") or p.get("url_c") or p.get("url_o") or p.get("url_m")
    thumb = p.get("url_q") or p.get("url_m") or image
    if not image: return
    li = xbmcgui.ListItem(title + ((" — " + owner) if owner else ""))
    li.setArt({"thumb": thumb, "icon": thumb, "fanart": image})
    li.setInfo("pictures", {"title": title, "artist": owner})
    xbmcplugin.addDirectoryItem(HANDLE, image, li, False)

def show_photos(title, photos):
    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, "images")
    for p in photos: add_photo(p)
    xbmcplugin.endOfDirectory(HANDLE)

def root():
    xbmcplugin.setPluginCategory(HANDLE, "Flickr")
    xbmcplugin.setContent(HANDLE, "files")
    add_folder("Explore / Interesting", "popular")
    add_folder("Recent Public Photos", "recent")
    add_folder("Search Flickr", "search")
    add_folder("Browse by Tag", "tag")
    add_folder("🔐 My Photos", "mine")
    add_folder("🔐 My Private Photos", "private")
    add_folder("🔐 My Albums", "sets")
    add_folder("Flickr Account / Sign In", "account")
    xbmcplugin.endOfDirectory(HANDLE)

def require_auth():
    if logged_in(): return True
    return authenticate()

def photos(method, title, **params):
    data = api_call(method,
        extras="owner_name,url_q,url_m,url_c,url_l,url_o,date_taken,tags",
        per_page=50, **params)
    if not data or data.get("stat") != "ok":
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    show_photos(title, data.get("photos", {}).get("photo", []))

def main():
    args = urllib.parse.parse_qs(urllib.parse.urlparse(sys.argv[2]).query)
    route = args.get("route", ["root"])[0]

    if route == "root": return root()
    if route == "account":
        if logged_in():
            name = get_saved("username") or "connected"
            xbmcgui.Dialog().ok("Flickr account", "Connected as: " + name)
        else:
            authenticate()
        xbmcplugin.endOfDirectory(HANDLE); return
    if route in ("mine", "private"):
        if not require_auth():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
        privacy = 0 if route == "mine" else 5
        return photos("flickr.people.getPhotos", "My Private Photos" if privacy else "My Photos",
                      user_id="me", privacy_filter=privacy)
    if route == "sets":
        if not require_auth():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
        data = api_call("flickr.photosets.getList", user_id="me", per_page=100)
        sets = data.get("photosets", {}).get("photoset", []) if data else []
        xbmcplugin.setContent(HANDLE, "files")
        for s in sets:
            li = xbmcgui.ListItem(s.get("title", {}).get("_content", "Album"))
            xbmcplugin.addDirectoryItem(
                HANDLE, make_url("set", id=s["id"]), li, True)
        xbmcplugin.endOfDirectory(HANDLE); return
    if route == "set":
        if not require_auth():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
        sid = args.get("id", [""])[0]
        data = api_call("flickr.photosets.getPhotos", photoset_id=sid, user_id="me",
                        privacy_filter=5,
                        extras="owner_name,url_q,url_m,url_c,url_l,url_o",
                        per_page=500)
        show_photos("Album", data.get("photoset", {}).get("photo", []) if data else [])
        return
    if route == "popular":
        return photos("flickr.photos.getPopular", "Explore", sort="interesting")
    if route == "recent":
        return photos("flickr.photos.getRecent", "Recent")
    if route == "search":
        q = xbmcgui.Dialog().input("Search Flickr", type=xbmcgui.INPUT_ALPHANUM)
        if q: return photos("flickr.photos.search", "Search: " + q, text=q)
    if route == "tag":
        q = xbmcgui.Dialog().input("Flickr tag", type=xbmcgui.INPUT_ALPHANUM)
        if q: return photos("flickr.photos.search", "Tag: " + q, tags=q)
    xbmcplugin.endOfDirectory(HANDLE)

main()
